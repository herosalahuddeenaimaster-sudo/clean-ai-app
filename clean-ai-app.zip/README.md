# Clean AI

An AI-powered media cleaning app: pick a photo or video, mark the area
you want gone, and get it back cleaned. No login, no sign-up, no
subscription, no credits, no profile.

```
clean-ai-app/
  backend/     Node/Express API (upload, jobs, mock AI provider)
  android/     Native Android app (Kotlin + Jetpack Compose)
```

## Run order

The Android app is a real client — it needs the backend running
somewhere it can reach.

### 1. Start the backend

```bash
cd backend
npm install
npm start
```

Runs on `http://localhost:8080` with `AI_PROVIDER=mock` (see
`backend/README.md` for the full API and how to swap in a real AI
vendor later).

### 2. Open the Android app

Open `android/` as a project in Android Studio (Ladybird/Koala or
newer) and let it sync Gradle. No manual wrapper setup needed —
Android Studio generates the Gradle wrapper on first sync.

- **Emulator**: works immediately. `BuildConfig.BASE_URL` in debug
  builds already points at `http://10.0.2.2:8080/`, which is the
  emulator's alias for your host machine's `localhost`.
- **Physical device**: edit the debug `BASE_URL` in
  `android/app/build.gradle.kts` to your computer's LAN IP (e.g.
  `http://192.168.1.50:8080/`), and make sure the phone is on the same
  Wi-Fi as the backend.

Run the `app` configuration onto an emulator or device.

### Command-line build (no Android Studio)

If you have the Android SDK installed and `ANDROID_HOME` set:

```bash
cd android
gradle wrapper          # one-time: generates gradlew/gradlew.bat
./gradlew assembleDebug # builds app/build/outputs/apk/debug/app-debug.apk
./gradlew installDebug  # installs it on a connected device/emulator
```

## What each layer owns

- **Backend** — receives uploads, creates jobs, runs the (mock, by
  default) AI provider, serves results, deletes temp files after
  retention. See `backend/README.md`.
- **Android app** — Home → Select (real Photo Picker) → Edit (real
  brush/rectangle mask drawing, real video playback) → Processing
  (polls real job status) → Result (real cleaned media, real
  MediaStore save).

## Known limitation

This was built in a sandboxed environment with no internet access and
no Android SDK, so neither `npm install` (backend) nor a Gradle build
(Android) could actually be run and verified here. Both codebases were
written and reviewed carefully by hand, but please build both locally
and watch for the first-run hiccups that are normal in any handoff —
see the "what to check first" section in `android/README-STATUS.md`
if something doesn't compile.
