# Retrofit / OkHttp / Gson models are reflected into — keep our DTOs intact.
-keep class com.cleanai.app.data.remote.dto.** { *; }
-keepattributes Signature
-keepattributes *Annotation*
-dontwarn okhttp3.**
-dontwarn retrofit2.**
