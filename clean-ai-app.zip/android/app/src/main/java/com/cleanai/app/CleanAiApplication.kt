package com.cleanai.app

import android.app.Application
import com.cleanai.app.di.ServiceLocator

class CleanAiApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        ServiceLocator.init(this)
    }
}
