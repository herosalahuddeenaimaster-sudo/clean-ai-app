package com.cleanai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.cleanai.app.di.ServiceLocator
import com.cleanai.app.navigation.CleanAiNavHost
import com.cleanai.app.ui.CleanFlowViewModel
import com.cleanai.app.ui.CleanFlowViewModelFactory
import com.cleanai.app.ui.theme.AppBackground
import com.cleanai.app.ui.theme.CleanAiTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CleanAiApp()
        }
    }
}

@Composable
private fun CleanAiApp() {
    CleanAiTheme {
        val viewModel: CleanFlowViewModel = viewModel(
            factory = CleanFlowViewModelFactory(ServiceLocator.repository),
        )
        androidx.compose.foundation.layout.Box(
            modifier = Modifier.fillMaxSize().background(AppBackground),
        ) {
            CleanAiNavHost(viewModel = viewModel)
        }
    }
}
