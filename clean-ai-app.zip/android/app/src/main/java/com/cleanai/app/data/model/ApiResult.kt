package com.cleanai.app.data.model

sealed class ApiResult<out T> {
    data class Success<T>(val data: T) : ApiResult<T>()
    data class Failure(val error: AppError, val debugMessage: String? = null) : ApiResult<Nothing>()
}

data class JobInfo(
    val jobId: String,
    val status: JobStatus,
    val progress: Int,
    val resultAvailable: Boolean,
    val errorMessage: String?,
)

enum class JobStatus {
    QUEUED, PROCESSING, COMPLETED, FAILED, CANCELLED;

    companion object {
        fun fromApiValue(value: String): JobStatus = when (value) {
            "queued" -> QUEUED
            "processing" -> PROCESSING
            "completed" -> COMPLETED
            "failed" -> FAILED
            "cancelled" -> CANCELLED
            else -> FAILED
        }
    }
}
