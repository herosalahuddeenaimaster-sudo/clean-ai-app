package com.cleanai.app.data.model

/**
 * Every failure the UI needs to react to, normalized into one small set.
 * Repositories translate network/IO exceptions and backend error codes
 * into these; screens only ever branch on this enum, never on raw
 * exceptions or HTTP status codes.
 */
enum class AppError {
    NO_INTERNET,
    UPLOAD_FAILED,
    INVALID_FILE,
    FILE_TOO_LARGE,
    PROCESSING_FAILED,
    TIMEOUT,
    SERVER_ERROR,
    CANCELLED,
    GENERIC,
}
