package com.cleanai.app.data.model

/** Mirrors the backend's `mediaType` string exactly ("image" / "video"). */
enum class MediaType(val apiValue: String) {
    IMAGE("image"),
    VIDEO("video"),
}
