package com.cleanai.app.data.remote

import com.cleanai.app.data.remote.dto.CreateJobRequestDto
import com.cleanai.app.data.remote.dto.JobResponseDto
import com.cleanai.app.data.remote.dto.UploadResponseDto
import okhttp3.MultipartBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Path
import retrofit2.http.Streaming

interface CleanAiApiService {

    @Multipart
    @POST("api/upload")
    suspend fun uploadFile(@Part file: MultipartBody.Part): Response<UploadResponseDto>

    @POST("api/jobs")
    suspend fun createJob(@Body request: CreateJobRequestDto): Response<JobResponseDto>

    @GET("api/jobs/{jobId}")
    suspend fun getJob(@Path("jobId") jobId: String): Response<JobResponseDto>

    @Streaming
    @GET("api/jobs/{jobId}/result")
    suspend fun getJobResult(@Path("jobId") jobId: String): Response<ResponseBody>

    @DELETE("api/jobs/{jobId}")
    suspend fun cancelJob(@Path("jobId") jobId: String): Response<JobResponseDto>
}
