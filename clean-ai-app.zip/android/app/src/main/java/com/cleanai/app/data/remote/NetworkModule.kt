package com.cleanai.app.data.remote

import com.cleanai.app.BuildConfig
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object NetworkModule {

    fun buildApiService(): CleanAiApiService {
        val logging = HttpLoggingInterceptor().apply {
            // Body-level logging only in debug builds — never log request/response
            // bodies (which may contain media bytes) in a release build.
            level = if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BASIC else HttpLoggingInterceptor.Level.NONE
        }

        val client = OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(2, TimeUnit.MINUTES) // media uploads can be large
            .readTimeout(2, TimeUnit.MINUTES)  // video results can take a while
            .addInterceptor(logging)
            .build()

        val retrofit = Retrofit.Builder()
            .baseUrl(BuildConfig.BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        return retrofit.create(CleanAiApiService::class.java)
    }
}
