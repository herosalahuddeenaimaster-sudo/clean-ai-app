package com.cleanai.app.data.remote.dto

import com.google.gson.annotations.SerializedName

/** Response from POST /api/upload. */
data class UploadResponseDto(
    @SerializedName("fileId") val fileId: String,
    @SerializedName("kind") val kind: String,
    @SerializedName("mimeType") val mimeType: String,
    @SerializedName("sizeBytes") val sizeBytes: Long?,
)

/** Request body for POST /api/jobs. */
data class CreateJobRequestDto(
    @SerializedName("mediaFileId") val mediaFileId: String,
    @SerializedName("maskFileId") val maskFileId: String,
    @SerializedName("mediaType") val mediaType: String,
)

/** Response from POST /api/jobs and GET /api/jobs/{id}. */
data class JobResponseDto(
    @SerializedName("jobId") val jobId: String,
    @SerializedName("status") val status: String, // queued | processing | completed | failed | cancelled
    @SerializedName("progress") val progress: Int,
    @SerializedName("mediaType") val mediaType: String,
    @SerializedName("error") val error: JobErrorDto?,
    @SerializedName("resultAvailable") val resultAvailable: Boolean,
)

data class JobErrorDto(
    @SerializedName("code") val code: String,
    @SerializedName("message") val message: String,
)

/** Shape of every error response body from the backend. */
data class ErrorEnvelopeDto(
    @SerializedName("error") val error: JobErrorDto?,
)
