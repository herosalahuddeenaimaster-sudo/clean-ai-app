package com.cleanai.app.data.repository

import com.cleanai.app.data.model.ApiResult
import com.cleanai.app.data.model.JobInfo
import com.cleanai.app.data.model.MediaType
import java.io.File

interface CleanRepository {
    /** Uploads a media or mask file, returns the backend fileId to reference in createJob. */
    suspend fun uploadFile(file: File, mimeType: String): ApiResult<String>

    suspend fun createJob(mediaFileId: String, maskFileId: String, mediaType: MediaType): ApiResult<JobInfo>

    suspend fun getJob(jobId: String): ApiResult<JobInfo>

    /** Streams the completed result to [destination] on disk. */
    suspend fun downloadResult(jobId: String, destination: File): ApiResult<String> // returns mime type

    suspend fun cancelJob(jobId: String): ApiResult<Unit>
}
