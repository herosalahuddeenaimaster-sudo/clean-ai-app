package com.cleanai.app.data.repository

import com.cleanai.app.data.model.ApiResult
import com.cleanai.app.data.model.AppError
import com.cleanai.app.data.model.JobInfo
import com.cleanai.app.data.model.JobStatus
import com.cleanai.app.data.model.MediaType
import com.cleanai.app.data.remote.CleanAiApiService
import com.cleanai.app.data.remote.dto.CreateJobRequestDto
import com.cleanai.app.data.remote.dto.ErrorEnvelopeDto
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import retrofit2.Response
import java.io.File
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class CleanRepositoryImpl(
    private val api: CleanAiApiService,
) : CleanRepository {

    private val gson = Gson()

    override suspend fun uploadFile(file: File, mimeType: String): ApiResult<String> = safeCall {
        val body = file.asRequestBody(mimeType.toMediaTypeOrNull())
        val part = MultipartBody.Part.createFormData("file", file.name, body)
        val response = api.uploadFile(part)
        mapResponse(response) { it.fileId }
    }

    override suspend fun createJob(mediaFileId: String, maskFileId: String, mediaType: MediaType): ApiResult<JobInfo> = safeCall {
        val response = api.createJob(CreateJobRequestDto(mediaFileId, maskFileId, mediaType.apiValue))
        mapResponse(response) { it.toJobInfo() }
    }

    override suspend fun getJob(jobId: String): ApiResult<JobInfo> = safeCall {
        val response = api.getJob(jobId)
        mapResponse(response) { it.toJobInfo() }
    }

    override suspend fun downloadResult(jobId: String, destination: File): ApiResult<String> = safeCall {
        val response = api.getJobResult(jobId)
        if (!response.isSuccessful || response.body() == null) {
            return@safeCall errorFromResponse(response.code(), response.errorBody()?.string())
        }
        response.body()!!.byteStream().use { input ->
            destination.outputStream().use { output -> input.copyTo(output) }
        }
        val mime = response.headers()["Content-Type"] ?: "application/octet-stream"
        ApiResult.Success(mime)
    }

    override suspend fun cancelJob(jobId: String): ApiResult<Unit> = safeCall {
        val response = api.cancelJob(jobId)
        mapResponse(response) { }
    }

    // ---------------------------------------------------------------
    // Shared plumbing
    // ---------------------------------------------------------------

    private suspend fun <T> safeCall(block: suspend () -> ApiResult<T>): ApiResult<T> = withContext(Dispatchers.IO) {
        try {
            block()
        } catch (e: UnknownHostException) {
            ApiResult.Failure(AppError.NO_INTERNET, e.message)
        } catch (e: SocketTimeoutException) {
            ApiResult.Failure(AppError.TIMEOUT, e.message)
        } catch (e: IOException) {
            ApiResult.Failure(AppError.NO_INTERNET, e.message)
        } catch (e: Exception) {
            ApiResult.Failure(AppError.GENERIC, e.message)
        }
    }

    private fun <D, T> mapResponse(response: Response<D>, onSuccess: (D) -> T): ApiResult<T> {
        val body = response.body()
        return if (response.isSuccessful && body != null) {
            ApiResult.Success(onSuccess(body))
        } else {
            errorFromResponse(response.code(), response.errorBody()?.string())
        }
    }

    private fun errorFromResponse(httpCode: Int, errorBody: String?): ApiResult.Failure {
        val parsedCode = try {
            errorBody?.let { gson.fromJson(it, ErrorEnvelopeDto::class.java)?.error?.code }
        } catch (e: Exception) {
            null
        }

        val error = when (parsedCode) {
            "UNSUPPORTED_FILE_TYPE", "NOT_A_MASK", "MEDIA_TYPE_MISMATCH", "INVALID_MEDIA_TYPE" -> AppError.INVALID_FILE
            "FILE_TOO_LARGE" -> AppError.FILE_TOO_LARGE
            "PROCESSING_FAILED", "SOURCE_FILE_MISSING" -> AppError.PROCESSING_FAILED
            else -> when {
                httpCode >= 500 -> AppError.SERVER_ERROR
                httpCode == 413 -> AppError.FILE_TOO_LARGE
                httpCode == 415 -> AppError.INVALID_FILE
                else -> AppError.GENERIC
            }
        }
        return ApiResult.Failure(error, "HTTP $httpCode: $parsedCode")
    }
}

private fun com.cleanai.app.data.remote.dto.JobResponseDto.toJobInfo() = JobInfo(
    jobId = jobId,
    status = JobStatus.fromApiValue(status),
    progress = progress,
    resultAvailable = resultAvailable,
    errorMessage = error?.message,
)
