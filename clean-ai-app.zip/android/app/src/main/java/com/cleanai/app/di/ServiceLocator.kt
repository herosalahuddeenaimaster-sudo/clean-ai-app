package com.cleanai.app.di

import android.content.Context
import coil.ImageLoader
import coil.decode.VideoFrameDecoder
import com.cleanai.app.data.remote.NetworkModule
import com.cleanai.app.data.repository.CleanRepository
import com.cleanai.app.data.repository.CleanRepositoryImpl

/**
 * Deliberately simple manual DI: this app has one repository and one
 * network client, so a dependency-injection framework (Hilt/Koin) would
 * be more ceremony than value. If the app grows, this is the file to
 * replace with Hilt modules — nothing else needs to change since
 * everything already depends on the CleanRepository *interface*.
 */
object ServiceLocator {
    lateinit var appContext: Context
        private set

    val repository: CleanRepository by lazy {
        CleanRepositoryImpl(NetworkModule.buildApiService())
    }

    /** Adds video-frame decoding so Coil can thumbnail a local video file/Uri, not just images. */
    val imageLoader: ImageLoader by lazy {
        ImageLoader.Builder(appContext)
            .components { add(VideoFrameDecoder.Factory()) }
            .build()
    }

    fun init(context: Context) {
        appContext = context.applicationContext
    }
}
