package com.cleanai.app.domain

/** A tool selection matches the prototype exactly: Brush or Rectangle. */
enum class MaskTool { BRUSH, RECTANGLE }

/** One point along a brush stroke, in the *displayed* canvas's pixel space. */
data class MaskPoint(val x: Float, val y: Float)

/** A single freehand brush stroke: an ordered list of points plus its radius. */
data class BrushStroke(val points: List<MaskPoint>, val radiusPx: Float)

/** A single marquee rectangle, in the *displayed* canvas's pixel space. */
data class MaskRect(val left: Float, val top: Float, val right: Float, val bottom: Float) {
    val width get() = kotlin.math.abs(right - left)
    val height get() = kotlin.math.abs(bottom - top)
    fun normalized() = MaskRect(
        left = minOf(left, right),
        top = minOf(top, bottom),
        right = maxOf(left, right),
        bottom = maxOf(top, bottom),
    )
}

/** Everything the user has drawn on the Edit screen for one media item. */
data class MaskDraft(
    val tool: MaskTool = MaskTool.BRUSH,
    val strokes: List<BrushStroke> = emptyList(),
    val rect: MaskRect? = null,
) {
    val isEmpty: Boolean get() = strokes.isEmpty() && rect == null
}
