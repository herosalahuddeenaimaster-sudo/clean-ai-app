package com.cleanai.app.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.cleanai.app.data.model.MediaType
import com.cleanai.app.ui.CleanFlowViewModel
import com.cleanai.app.ui.screens.edit.EditScreen
import com.cleanai.app.ui.screens.home.HomeScreen
import com.cleanai.app.ui.screens.processing.ProcessingScreen
import com.cleanai.app.ui.screens.result.ResultScreen
import com.cleanai.app.ui.screens.select.SelectScreen

@Composable
fun CleanAiNavHost(viewModel: CleanFlowViewModel) {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = Screen.Home.route) {
        composable(Screen.Home.route) {
            HomeScreen(
                onCleanVideo = {
                    viewModel.startNewFlow(MediaType.VIDEO)
                    navController.navigate(Screen.Select.route)
                },
                onCleanImage = {
                    viewModel.startNewFlow(MediaType.IMAGE)
                    navController.navigate(Screen.Select.route)
                },
            )
        }

        composable(Screen.Select.route) {
            SelectScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onContinue = { navController.navigate(Screen.Edit.route) },
            )
        }

        composable(Screen.Edit.route) {
            EditScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onNavigateToProcessing = { navController.navigate(Screen.Processing.route) },
            )
        }

        composable(Screen.Processing.route) {
            ProcessingScreen(
                viewModel = viewModel,
                onCompleted = {
                    navController.navigate(Screen.Result.route) {
                        popUpTo(Screen.Home.route) { inclusive = false }
                    }
                },
                onBackToEdit = { navController.popBackStack() },
            )
        }

        composable(Screen.Result.route) {
            ResultScreen(
                viewModel = viewModel,
                onCleanAnother = {
                    navController.popBackStack(Screen.Home.route, inclusive = false)
                },
            )
        }
    }
}
