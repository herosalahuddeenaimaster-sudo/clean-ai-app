package com.cleanai.app.navigation

sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object Select : Screen("select")
    data object Edit : Screen("edit")
    data object Processing : Screen("processing")
    data object Result : Screen("result")
}
