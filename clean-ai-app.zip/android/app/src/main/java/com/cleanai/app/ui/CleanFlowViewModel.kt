package com.cleanai.app.ui

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cleanai.app.data.model.ApiResult
import com.cleanai.app.data.model.AppError
import com.cleanai.app.data.model.JobStatus
import com.cleanai.app.data.model.MediaType
import com.cleanai.app.data.repository.CleanRepository
import com.cleanai.app.domain.MaskDraft
import com.cleanai.app.util.MaskBitmapGenerator
import com.cleanai.app.util.MediaStoreSaver
import com.cleanai.app.util.PickedFileInfo
import com.cleanai.app.util.UriFileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File

enum class JobPhase {
    IDLE,        // nothing picked / nothing submitted yet
    PREPARING,   // rendering the mask bitmap
    UPLOADING,   // sending media + mask to the backend
    QUEUED,      // job created, waiting for a worker
    PROCESSING,  // backend actively cleaning the media
    DOWNLOADING, // job completed, pulling the result bytes down
    COMPLETED,
    FAILED,
    CANCELLED,
}

data class CleanUiState(
    val mediaType: MediaType? = null,
    val pickedFile: PickedFileInfo? = null,
    val mediaWidth: Int = 0,
    val mediaHeight: Int = 0,
    val videoDurationMs: Long = 0,
    val maskFile: File? = null,
    val jobId: String? = null,
    val jobPhase: JobPhase = JobPhase.IDLE,
    val progress: Int = 0,
    val error: AppError? = null,
    val resultFile: File? = null,
    val resultMimeType: String? = null,
    val savedEvent: Int = 0, // bumped each successful gallery save, screens key a one-shot toast off it
)

class CleanFlowViewModel(
    private val repository: CleanRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(CleanUiState())
    val uiState: StateFlow<CleanUiState> = _uiState

    // ------------------------------------------------------------
    // Home -> Select
    // ------------------------------------------------------------
    fun startNewFlow(mediaType: MediaType) {
        cleanupFiles(_uiState.value)
        _uiState.value = CleanUiState(mediaType = mediaType)
    }

    // ------------------------------------------------------------
    // Select screen
    // ------------------------------------------------------------
    suspend fun onMediaPicked(context: Context, uri: Uri): Boolean {
        val mediaType = _uiState.value.mediaType ?: return false
        return try {
            val picked = UriFileUtils.copyToCache(context, uri, subDir = "picked")

            val maxBytes = if (mediaType == MediaType.VIDEO) 200L * 1024 * 1024 else 20L * 1024 * 1024
            if (picked.sizeBytes > maxBytes) {
                picked.file.delete()
                _uiState.update { it.copy(error = AppError.FILE_TOO_LARGE) }
                return false
            }
            val mimeOk = if (mediaType == MediaType.VIDEO) picked.mimeType.startsWith("video/") else picked.mimeType.startsWith("image/")
            if (!mimeOk) {
                picked.file.delete()
                _uiState.update { it.copy(error = AppError.INVALID_FILE) }
                return false
            }

            val (w, h, durationMs) = withContext(Dispatchers.IO) {
                if (mediaType == MediaType.VIDEO) {
                    UriFileUtils.readVideoMetadata(picked.file)
                } else {
                    val (iw, ih) = UriFileUtils.readImageDimensions(picked.file)
                    Triple(iw, ih, 0L)
                }
            }

            if (w <= 0 || h <= 0) {
                picked.file.delete()
                _uiState.update { it.copy(error = AppError.INVALID_FILE) }
                return false
            }

            _uiState.update {
                it.copy(pickedFile = picked, mediaWidth = w, mediaHeight = h, videoDurationMs = durationMs, error = null)
            }
            true
        } catch (e: Exception) {
            _uiState.update { it.copy(error = AppError.INVALID_FILE) }
            false
        }
    }

    fun changeMedia() {
        _uiState.value.pickedFile?.file?.delete()
        _uiState.update { it.copy(pickedFile = null, mediaWidth = 0, mediaHeight = 0, videoDurationMs = 0, error = null) }
    }

    // ------------------------------------------------------------
    // Edit screen -> kicks off the whole backend pipeline
    // ------------------------------------------------------------
    fun startCleaning(context: Context, draft: MaskDraft, boxWidthPx: Float, boxHeightPx: Float) {
        val current = _uiState.value
        if (current.jobPhase != JobPhase.IDLE && current.jobPhase != JobPhase.FAILED) return // ignore double taps
        val picked = current.pickedFile ?: return

        viewModelScope.launch {
            _uiState.update { it.copy(jobPhase = JobPhase.PREPARING, error = null, progress = 2) }

            val maskFile = File(context.cacheDir, "mask_${System.currentTimeMillis()}.png")
            val hasMask = withContext(Dispatchers.Default) {
                MaskBitmapGenerator.renderToFile(
                    draft = draft,
                    boxWidth = boxWidthPx,
                    boxHeight = boxHeightPx,
                    naturalWidth = current.mediaWidth,
                    naturalHeight = current.mediaHeight,
                    outputFile = maskFile,
                )
            }
            if (!hasMask) {
                fail(AppError.GENERIC)
                return@launch
            }

            _uiState.update { it.copy(maskFile = maskFile) }
            runPipeline(context, picked)
        }
    }

    /** Re-runs upload -> job -> poll -> download using the already-picked media and already-rendered mask. */
    fun retry(context: Context) {
        val state = _uiState.value
        val picked = state.pickedFile ?: return
        if (state.maskFile == null) return // nothing to retry from; user needs to go back and mark again
        viewModelScope.launch { runPipeline(context, picked) }
    }

    private suspend fun runPipeline(context: Context, picked: PickedFileInfo) {
        val state = _uiState.value
        val maskFile = state.maskFile ?: return fail(AppError.GENERIC)
        val mediaType = state.mediaType ?: return fail(AppError.GENERIC)

        _uiState.update { it.copy(jobPhase = JobPhase.UPLOADING, progress = 5, error = null, jobId = null) }

        val mediaUpload = repository.uploadFile(picked.file, picked.mimeType)
        val mediaFileId = when (mediaUpload) {
            is ApiResult.Success -> mediaUpload.data
            is ApiResult.Failure -> return fail(mediaUpload.error)
        }
        _uiState.update { it.copy(progress = 20) }

        val maskUpload = repository.uploadFile(maskFile, "image/png")
        val maskFileId = when (maskUpload) {
            is ApiResult.Success -> maskUpload.data
            is ApiResult.Failure -> return fail(maskUpload.error)
        }
        _uiState.update { it.copy(progress = 35, jobPhase = JobPhase.QUEUED) }

        val createResult = repository.createJob(mediaFileId, maskFileId, mediaType)
        val job = when (createResult) {
            is ApiResult.Success -> createResult.data
            is ApiResult.Failure -> return fail(createResult.error)
        }
        _uiState.update { it.copy(jobId = job.jobId, progress = maxOf(it.progress, job.progress)) }

        pollUntilDone(context, job.jobId)
    }

    private suspend fun pollUntilDone(context: Context, jobId: String) {
        val timeoutMs = if (_uiState.value.mediaType == MediaType.VIDEO) 150_000L else 90_000L
        var outcome: JobStatus? = null

        val completedWithinTimeout = withTimeoutOrNull(timeoutMs) {
            while (outcome == null) {
                kotlinx.coroutines.delay(1500)
                when (val result = repository.getJob(jobId)) {
                    is ApiResult.Success -> {
                        val info = result.data
                        _uiState.update { current ->
                            current.copy(
                                progress = maxOf(current.progress, info.progress),
                                jobPhase = when (info.status) {
                                    JobStatus.PROCESSING -> JobPhase.PROCESSING
                                    JobStatus.QUEUED -> JobPhase.QUEUED
                                    else -> current.jobPhase
                                },
                            )
                        }
                        if (info.status == JobStatus.COMPLETED || info.status == JobStatus.FAILED || info.status == JobStatus.CANCELLED) {
                            outcome = info.status
                        }
                    }
                    is ApiResult.Failure -> {
                        fail(result.error)
                        outcome = JobStatus.FAILED
                    }
                }
            }
        }

        if (completedWithinTimeout == null) {
            fail(AppError.TIMEOUT)
            return
        }

        when (outcome) {
            JobStatus.COMPLETED -> downloadResult(context, jobId)
            JobStatus.CANCELLED -> _uiState.update { it.copy(jobPhase = JobPhase.CANCELLED) }
            else -> if (_uiState.value.jobPhase != JobPhase.FAILED) fail(AppError.PROCESSING_FAILED)
        }
    }

    private suspend fun downloadResult(context: Context, jobId: String) {
        _uiState.update { it.copy(jobPhase = JobPhase.DOWNLOADING, progress = maxOf(it.progress, 95)) }
        val ext = if (_uiState.value.mediaType == MediaType.VIDEO) "mp4" else "jpg"
        val destFile = File(context.cacheDir, "result_${jobId}.$ext")

        when (val result = repository.downloadResult(jobId, destFile)) {
            is ApiResult.Success -> _uiState.update {
                it.copy(jobPhase = JobPhase.COMPLETED, progress = 100, resultFile = destFile, resultMimeType = result.data)
            }
            is ApiResult.Failure -> fail(result.error)
        }
    }

    fun cancelJob(context: Context) {
        val jobId = _uiState.value.jobId
        viewModelScope.launch {
            if (jobId != null) repository.cancelJob(jobId)
            _uiState.update { it.copy(jobPhase = JobPhase.CANCELLED) }
        }
    }

    private fun fail(error: AppError) {
        _uiState.update { it.copy(jobPhase = JobPhase.FAILED, error = error) }
    }

    fun consumeError() {
        _uiState.update { it.copy(error = null) }
    }

    // ------------------------------------------------------------
    // Result screen
    // ------------------------------------------------------------
    fun saveToGallery(context: Context) {
        val state = _uiState.value
        val resultFile = state.resultFile ?: return
        val mediaType = state.mediaType ?: return

        viewModelScope.launch {
            try {
                val ext = if (mediaType == MediaType.VIDEO) "mp4" else "jpg"
                val displayName = "clean-ai-${System.currentTimeMillis()}.$ext"
                val mime = state.resultMimeType ?: if (mediaType == MediaType.VIDEO) "video/mp4" else "image/jpeg"
                MediaStoreSaver.saveToGallery(context, resultFile, mediaType, mime, displayName)
                _uiState.update { it.copy(savedEvent = it.savedEvent + 1) }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = AppError.GENERIC) }
            }
        }
    }

    /** "Clean Another" — clears everything so Home/Select start fresh. */
    fun resetFlow() {
        cleanupFiles(_uiState.value)
        _uiState.value = CleanUiState()
    }

    private fun cleanupFiles(state: CleanUiState) {
        state.pickedFile?.file?.delete()
        state.maskFile?.delete()
        state.resultFile?.delete()
    }

    override fun onCleared() {
        cleanupFiles(_uiState.value)
        super.onCleared()
    }
}
