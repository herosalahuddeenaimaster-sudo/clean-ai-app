package com.cleanai.app.ui

import androidx.annotation.StringRes
import com.cleanai.app.R
import com.cleanai.app.data.model.AppError

@StringRes
fun AppError.messageRes(): Int = when (this) {
    AppError.NO_INTERNET -> R.string.error_no_internet
    AppError.UPLOAD_FAILED -> R.string.error_upload_failed
    AppError.INVALID_FILE -> R.string.error_invalid_file
    AppError.FILE_TOO_LARGE -> R.string.error_file_too_large
    AppError.PROCESSING_FAILED -> R.string.error_processing_failed
    AppError.TIMEOUT -> R.string.error_timeout
    AppError.SERVER_ERROR -> R.string.error_server
    AppError.CANCELLED -> R.string.error_cancelled
    AppError.GENERIC -> R.string.error_generic
}
