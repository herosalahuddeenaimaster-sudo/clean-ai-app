package com.cleanai.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

private val defaultStroke = 1.8f

@Composable
fun BackArrowIcon(color: Color, modifier: Modifier = Modifier, size: androidx.compose.ui.unit.Dp = 18.dp) {
    Canvas(modifier.size(size)) {
        val w = this.size.width; val h = this.size.height
        val path = Path().apply {
            moveTo(w * 0.62f, h * 0.15f)
            lineTo(w * 0.30f, h * 0.5f)
            lineTo(w * 0.62f, h * 0.85f)
        }
        drawPath(path, color, style = Stroke(width = w * 0.11f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

@Composable
fun ChevronRightIcon(color: Color, modifier: Modifier = Modifier, size: androidx.compose.ui.unit.Dp = 16.dp) {
    Canvas(modifier.size(size)) {
        val w = this.size.width; val h = this.size.height
        val path = Path().apply {
            moveTo(w * 0.36f, h * 0.15f)
            lineTo(w * 0.68f, h * 0.5f)
            lineTo(w * 0.36f, h * 0.85f)
        }
        drawPath(path, color, style = Stroke(width = w * 0.13f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

@Composable
fun PlusIcon(color: Color, modifier: Modifier = Modifier, size: androidx.compose.ui.unit.Dp = 12.dp) {
    Canvas(modifier.size(size)) {
        val w = this.size.width; val h = this.size.height
        val stroke = Stroke(width = w * 0.16f, cap = StrokeCap.Round)
        drawLine(color, Offset(w / 2, h * 0.12f), Offset(w / 2, h * 0.88f), strokeWidth = stroke.width, cap = StrokeCap.Round)
        drawLine(color, Offset(w * 0.12f, h / 2), Offset(w * 0.88f, h / 2), strokeWidth = stroke.width, cap = StrokeCap.Round)
    }
}

@Composable
fun VideoIcon(color: Color, modifier: Modifier = Modifier, size: androidx.compose.ui.unit.Dp = 26.dp) {
    Canvas(modifier.size(size)) {
        val w = this.size.width; val h = this.size.height
        val strokeW = w * 0.075f
        drawRoundRect(
            color = color,
            topLeft = Offset(w * 0.12f, h * 0.2f),
            size = Size(w * 0.58f, h * 0.6f),
            cornerRadius = CornerRadius(w * 0.16f),
            style = Stroke(strokeW, cap = StrokeCap.Round, join = StrokeJoin.Round),
        )
        val flag = Path().apply {
            moveTo(w * 0.72f, h * 0.42f)
            lineTo(w * 0.9f, h * 0.3f)
            lineTo(w * 0.9f, h * 0.7f)
            close()
        }
        drawPath(flag, color)
    }
}

@Composable
fun ImageIcon(color: Color, modifier: Modifier = Modifier, size: androidx.compose.ui.unit.Dp = 26.dp) {
    Canvas(modifier.size(size)) {
        val w = this.size.width; val h = this.size.height
        val strokeW = w * 0.075f
        drawRoundRect(
            color = color,
            topLeft = Offset(w * 0.1f, h * 0.15f),
            size = Size(w * 0.8f, h * 0.7f),
            cornerRadius = CornerRadius(w * 0.14f),
            style = Stroke(strokeW, cap = StrokeCap.Round, join = StrokeJoin.Round),
        )
        drawCircle(color, radius = w * 0.065f, center = Offset(w * 0.32f, h * 0.38f))
        val mountains = Path().apply {
            moveTo(w * 0.16f, h * 0.68f)
            lineTo(w * 0.36f, h * 0.46f)
            lineTo(w * 0.52f, h * 0.62f)
            lineTo(w * 0.65f, h * 0.5f)
            lineTo(w * 0.86f, h * 0.7f)
        }
        drawPath(mountains, color, style = Stroke(strokeW, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

@Composable
fun BrushIcon(color: Color, modifier: Modifier = Modifier, size: androidx.compose.ui.unit.Dp = 15.dp) {
    Canvas(modifier.size(size)) {
        val w = this.size.width; val h = this.size.height
        val strokeW = w * 0.14f
        val handle = Path().apply {
            moveTo(w * 0.4f, h * 0.62f)
            lineTo(w * 0.78f, h * 0.24f)
        }
        drawPath(handle, color, style = Stroke(strokeW, cap = StrokeCap.Round))
        drawCircle(color, radius = w * 0.16f, center = Offset(w * 0.82f, h * 0.2f))
        val tip = Path().apply {
            moveTo(w * 0.4f, h * 0.62f)
            quadraticBezierTo(w * 0.24f, h * 0.7f, w * 0.18f, h * 0.9f)
            quadraticBezierTo(w * 0.36f, h * 0.84f, w * 0.4f, h * 0.62f)
            close()
        }
        drawPath(tip, color)
    }
}

@Composable
fun RectangleToolIcon(color: Color, modifier: Modifier = Modifier, size: androidx.compose.ui.unit.Dp = 15.dp) {
    Canvas(modifier.size(size)) {
        val w = this.size.width; val h = this.size.height
        drawRoundRect(
            color = color,
            topLeft = Offset(w * 0.12f, h * 0.12f),
            size = Size(w * 0.76f, h * 0.76f),
            cornerRadius = CornerRadius(w * 0.12f),
            style = Stroke(
                width = w * 0.13f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(w * 0.16f, w * 0.13f)),
            ),
        )
    }
}

@Composable
fun ClearIcon(color: Color, modifier: Modifier = Modifier, size: androidx.compose.ui.unit.Dp = 14.dp) {
    Canvas(modifier.size(size)) {
        val w = this.size.width; val h = this.size.height
        val strokeW = w * 0.11f
        drawLine(color, Offset(w * 0.15f, h * 0.28f), Offset(w * 0.85f, h * 0.28f), strokeW, cap = StrokeCap.Round)
        drawLine(color, Offset(w * 0.38f, h * 0.28f), Offset(w * 0.38f, h * 0.18f), strokeW, cap = StrokeCap.Round)
        drawLine(color, Offset(w * 0.62f, h * 0.28f), Offset(w * 0.62f, h * 0.18f), strokeW, cap = StrokeCap.Round)
        val bin = Path().apply {
            moveTo(w * 0.24f, h * 0.32f)
            lineTo(w * 0.3f, h * 0.88f)
            quadraticBezierTo(w * 0.3f, h * 0.94f, w * 0.38f, h * 0.94f)
            lineTo(w * 0.62f, h * 0.94f)
            quadraticBezierTo(w * 0.7f, h * 0.94f, w * 0.7f, h * 0.88f)
            lineTo(w * 0.76f, h * 0.32f)
        }
        drawPath(bin, color, style = Stroke(strokeW, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

@Composable
fun CheckIcon(color: Color, modifier: Modifier = Modifier, size: androidx.compose.ui.unit.Dp = 20.dp) {
    Canvas(modifier.size(size)) {
        val w = this.size.width; val h = this.size.height
        val path = Path().apply {
            moveTo(w * 0.18f, h * 0.52f)
            lineTo(w * 0.42f, h * 0.74f)
            lineTo(w * 0.84f, h * 0.28f)
        }
        drawPath(path, color, style = Stroke(w * 0.13f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

@Composable
fun DownloadIcon(color: Color, modifier: Modifier = Modifier, size: androidx.compose.ui.unit.Dp = 17.dp) {
    Canvas(modifier.size(size)) {
        val w = this.size.width; val h = this.size.height
        val strokeW = w * 0.11f
        drawLine(color, Offset(w / 2, h * 0.1f), Offset(w / 2, h * 0.6f), strokeW, cap = StrokeCap.Round)
        val arrow = Path().apply {
            moveTo(w * 0.28f, h * 0.42f)
            lineTo(w / 2, h * 0.64f)
            lineTo(w * 0.72f, h * 0.42f)
        }
        drawPath(arrow, color, style = Stroke(strokeW, cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawLine(color, Offset(w * 0.18f, h * 0.88f), Offset(w * 0.82f, h * 0.88f), strokeW, cap = StrokeCap.Round)
    }
}

@Composable
fun PauseIcon(color: Color, modifier: Modifier = Modifier, size: androidx.compose.ui.unit.Dp = 20.dp) {
    Canvas(modifier.size(size)) {
        val w = this.size.width; val h = this.size.height
        val barW = w * 0.16f
        drawRoundRect(color, topLeft = Offset(w * 0.28f, h * 0.22f), size = Size(barW, h * 0.56f), cornerRadius = CornerRadius(barW * 0.3f))
        drawRoundRect(color, topLeft = Offset(w * 0.56f, h * 0.22f), size = Size(barW, h * 0.56f), cornerRadius = CornerRadius(barW * 0.3f))
    }
}

@Composable
fun PlayIcon(color: Color, modifier: Modifier = Modifier, size: androidx.compose.ui.unit.Dp = 20.dp) {
    Canvas(modifier.size(size)) {
        val w = this.size.width; val h = this.size.height
        val path = Path().apply {
            moveTo(w * 0.32f, h * 0.2f)
            lineTo(w * 0.82f, h * 0.5f)
            lineTo(w * 0.32f, h * 0.8f)
            close()
        }
        drawPath(path, color)
    }
}

@Composable
fun SparkleIcon(color: Color, modifier: Modifier = Modifier, size: androidx.compose.ui.unit.Dp = 18.dp) {
    Canvas(modifier.size(size)) {
        val w = this.size.width; val h = this.size.height
        val path = Path().apply {
            moveTo(w * 0.5f, h * 0.05f)
            lineTo(w * 0.6f, h * 0.4f)
            lineTo(w * 0.95f, h * 0.5f)
            lineTo(w * 0.6f, h * 0.6f)
            lineTo(w * 0.5f, h * 0.95f)
            lineTo(w * 0.4f, h * 0.6f)
            lineTo(w * 0.05f, h * 0.5f)
            lineTo(w * 0.4f, h * 0.4f)
            close()
        }
        drawPath(path, color)
    }
}

@Composable
fun ShieldIcon(color: Color, modifier: Modifier = Modifier, size: androidx.compose.ui.unit.Dp = 14.dp) {
    Canvas(modifier.size(size)) {
        val w = this.size.width; val h = this.size.height
        val path = Path().apply {
            moveTo(w * 0.5f, h * 0.05f)
            lineTo(w * 0.88f, h * 0.2f)
            lineTo(w * 0.88f, h * 0.5f)
            quadraticBezierTo(w * 0.88f, h * 0.85f, w * 0.5f, h * 0.97f)
            quadraticBezierTo(w * 0.12f, h * 0.85f, w * 0.12f, h * 0.5f)
            lineTo(w * 0.12f, h * 0.2f)
            close()
        }
        drawPath(path, color, style = Stroke(w * 0.11f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}
