package com.cleanai.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.cleanai.app.ui.theme.Accent
import com.cleanai.app.ui.theme.AccentSoft
import com.cleanai.app.ui.theme.Ink
import com.cleanai.app.ui.theme.InkSoft
import com.cleanai.app.ui.theme.RadiusLg
import com.cleanai.app.ui.theme.Surface

@Composable
fun MediaCard(
    title: String,
    description: String,
    iconGradientStart: Color,
    iconGradientEnd: Color,
    icon: @Composable () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val interactionSource = remember { MutableInteractionSource() }
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RadiusLg)
            .background(Surface)
            .border(1.dp, Color.White.copy(alpha = 0.6f), RadiusLg)
            .clickable(interactionSource = interactionSource, indication = null, onClick = onClick)
            .padding(20.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Brush.linearGradient(listOf(iconGradientStart, iconGradientEnd), start = Offset(0f, 0f), end = Offset(200f, 200f))),
            contentAlignment = Alignment.Center,
        ) { icon() }

        Spacer(Modifier.width(16.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = Ink)
            Text(description, style = MaterialTheme.typography.bodyMedium, color = InkSoft)
        }

        Spacer(Modifier.width(16.dp))

        Box(
            modifier = Modifier.size(38.dp).clip(CircleShape).background(AccentSoft),
            contentAlignment = Alignment.Center,
        ) { ChevronRightIcon(color = Accent) }
    }
}
