package com.cleanai.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.cleanai.app.R
import com.cleanai.app.domain.MaskTool
import com.cleanai.app.ui.theme.Accent
import com.cleanai.app.ui.theme.AccentSoft
import com.cleanai.app.ui.theme.InkSoft
import com.cleanai.app.ui.theme.Surface

@Composable
fun ToolSegmentedControl(
    selected: MaskTool,
    onSelect: (MaskTool) -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .shadow(6.dp, RoundedCornerShape(16.dp), clip = false)
            .clip(RoundedCornerShape(16.dp))
            .background(Surface)
            .padding(4.dp),
    ) {
        ToolChip(
            label = stringResource(R.string.tool_brush),
            selected = selected == MaskTool.BRUSH,
            onClick = { onSelect(MaskTool.BRUSH) },
            icon = { tint -> BrushIcon(color = tint) },
        )
        ToolChip(
            label = stringResource(R.string.tool_rectangle),
            selected = selected == MaskTool.RECTANGLE,
            onClick = { onSelect(MaskTool.RECTANGLE) },
            icon = { tint -> RectangleToolIcon(color = tint) },
        )
    }
}

@Composable
private fun ToolChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    icon: @Composable (androidx.compose.ui.graphics.Color) -> Unit,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val tint = if (selected) Accent else InkSoft
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) AccentSoft else Surface)
            .clickable(interactionSource = interactionSource, indication = null, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        icon(tint)
        androidx.compose.foundation.layout.Spacer(Modifier.width(6.dp))
        Text(label, color = tint, style = MaterialTheme.typography.labelSmall)
    }
}
