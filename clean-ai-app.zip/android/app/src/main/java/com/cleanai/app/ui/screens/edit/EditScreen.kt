package com.cleanai.app.ui.screens.edit

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.cleanai.app.R
import com.cleanai.app.data.model.MediaType
import com.cleanai.app.di.ServiceLocator
import com.cleanai.app.domain.MaskTool
import com.cleanai.app.ui.CleanFlowViewModel
import com.cleanai.app.ui.components.ClearIcon
import com.cleanai.app.ui.components.ErrorBanner
import com.cleanai.app.ui.components.PrimaryButton
import com.cleanai.app.ui.components.ScreenHeader
import com.cleanai.app.ui.components.ToolSegmentedControl
import com.cleanai.app.ui.messageRes
import com.cleanai.app.ui.theme.Accent
import com.cleanai.app.ui.theme.AccentSoft
import com.cleanai.app.ui.theme.AppBackground
import com.cleanai.app.ui.theme.CanvasDark
import com.cleanai.app.ui.theme.CanvasDark2
import com.cleanai.app.ui.theme.Ink
import com.cleanai.app.ui.theme.InkFaint
import com.cleanai.app.ui.theme.InkSoft
import com.cleanai.app.ui.theme.Surface

private val brushDiameters = listOf(14.dp, 24.dp, 38.dp)

@Composable
fun EditScreen(
    viewModel: CleanFlowViewModel,
    onBack: () -> Unit,
    onNavigateToProcessing: () -> Unit,
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val density = LocalDensity.current
    val mediaType = uiState.mediaType ?: MediaType.IMAGE
    val pickedFile = uiState.pickedFile

    val canvasState = rememberMaskCanvasState()
    var boxSize by remember { mutableStateOf(IntSize.Zero) }
    var selectedDiameterIndex by remember { mutableStateOf(1) }

    // Fresh mask every time a new media item lands on this screen.
    LaunchedEffect(pickedFile) {
        canvasState.clear()
        canvasState.brushRadiusPx = with(density) { brushDiameters[selectedDiameterIndex].toPx() / 2f }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AppBackground)
            .padding(horizontal = 24.dp)
            .padding(top = 14.dp, bottom = 22.dp),
    ) {
        ScreenHeader(title = stringResource(R.string.mark_the_area), onBack = onBack)

        Text(
            stringResource(R.string.edit_hint),
            style = MaterialTheme.typography.bodyMedium,
            color = InkSoft,
            modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )

        ErrorBanner(message = uiState.error?.let { stringResource(it.messageRes()) }, modifier = Modifier.padding(bottom = 10.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(28.dp))
                .background(Brush.linearGradient(listOf(CanvasDark, CanvasDark2)))
                .onSizeChanged { boxSize = it },
        ) {
            if (pickedFile != null) {
                if (mediaType == MediaType.VIDEO) {
                    VideoPreviewPlayer(uri = Uri.fromFile(pickedFile.file), modifier = Modifier.fillMaxSize())
                } else {
                    AsyncImage(
                        model = pickedFile.file,
                        imageLoader = ServiceLocator.imageLoader,
                        contentDescription = null,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }
            MaskCanvas(state = canvasState, modifier = Modifier.fillMaxSize())
        }

        Spacer(Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            ToolSegmentedControl(
                selected = canvasState.tool,
                onSelect = { canvasState.tool = it },
            )
            ClearChip(enabled = canvasState.canUndo, onClick = { canvasState.undo() })
        }

        if (canvasState.tool == MaskTool.BRUSH) {
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = stringResource(R.string.size_label), style = MaterialTheme.typography.bodySmall, color = InkFaint)
                Spacer(Modifier.width(10.dp))
                brushDiameters.forEachIndexed { index, diameter ->
                    SizeDot(
                        diameter = diameter,
                        selected = selectedDiameterIndex == index,
                        onClick = {
                            selectedDiameterIndex = index
                            canvasState.brushRadiusPx = with(density) { diameter.toPx() / 2f }
                        },
                    )
                    Spacer(Modifier.width(10.dp))
                }
            }
        }

        Spacer(Modifier.height(18.dp))

        PrimaryButton(
            text = stringResource(R.string.clean),
            enabled = canvasState.hasMask && pickedFile != null,
            onClick = {
                onNavigateToProcessing()
                viewModel.startCleaning(
                    context = context,
                    draft = canvasState.toDraft(),
                    boxWidthPx = boxSize.width.toFloat(),
                    boxHeightPx = boxSize.height.toFloat(),
                )
            },
        )
    }
}

@Composable
private fun ClearChip(enabled: Boolean, onClick: () -> Unit) {
    val interactionSource = remember { MutableInteractionSource() }
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Surface)
            .clickable(enabled = enabled, interactionSource = interactionSource, indication = null, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val tint = if (enabled) InkSoft else InkFaint
        ClearIcon(color = tint)
        Spacer(Modifier.width(6.dp))
        Text(stringResource(R.string.clear), color = tint, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun SizeDot(diameter: androidx.compose.ui.unit.Dp, selected: Boolean, onClick: () -> Unit) {
    val interactionSource = remember { MutableInteractionSource() }
    Box(
        modifier = Modifier
            .size(34.dp)
            .clip(CircleShape)
            .background(if (selected) AccentSoft else Surface)
            .clickable(interactionSource = interactionSource, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier = Modifier
                .size(diameter * 0.42f)
                .clip(CircleShape)
                .background(if (selected) Accent else InkFaint),
        )
    }
}
