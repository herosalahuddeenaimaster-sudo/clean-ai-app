package com.cleanai.app.ui.screens.edit

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import com.cleanai.app.domain.BrushStroke
import com.cleanai.app.domain.MaskDraft
import com.cleanai.app.domain.MaskPoint
import com.cleanai.app.domain.MaskRect
import com.cleanai.app.domain.MaskTool
import com.cleanai.app.ui.theme.MaskOverlay

/**
 * Owns the actual drawing data so parent buttons (Clear, Clean) can read
 * or reset it without the canvas re-subscribing on every recomposition.
 * Undo removes the most recent committed stroke/rectangle.
 */
class MaskCanvasState(initialTool: MaskTool = MaskTool.BRUSH) {
    var tool by mutableStateOf(initialTool)
    var brushRadiusPx by mutableStateOf(12f)

    val strokes = mutableStateListOf<BrushStroke>()
    var rect by mutableStateOf<MaskRect?>(null)

    val hasMask: Boolean get() = strokes.isNotEmpty() || rect != null
    val canUndo: Boolean get() = hasMask

    fun clear() {
        strokes.clear()
        rect = null
    }

    /** Removes the last thing the user drew (last stroke, or the rectangle). */
    fun undo() {
        if (tool == MaskTool.RECTANGLE) {
            rect = null
        } else if (strokes.isNotEmpty()) {
            strokes.removeAt(strokes.lastIndex)
        }
    }

    fun toDraft(): MaskDraft = MaskDraft(tool = tool, strokes = strokes.toList(), rect = rect)
}

@Composable
fun rememberMaskCanvasState(): MaskCanvasState = remember { MaskCanvasState() }

@Composable
fun MaskCanvas(
    state: MaskCanvasState,
    modifier: Modifier = Modifier,
) {
    // In-progress drawing (not yet committed) so a stroke/rect renders
    // smoothly while dragging without touching the committed lists.
    var liveStrokePoints by remember { mutableStateOf<List<MaskPoint>>(emptyList()) }
    var liveRectStart by remember { mutableStateOf<Offset?>(null) }
    var liveRectEnd by remember { mutableStateOf<Offset?>(null) }

    Canvas(
        modifier = modifier
            .pointerInput(state.tool) {
                if (state.tool == MaskTool.BRUSH) {
                    detectDragGestures(
                        onDragStart = { offset -> liveStrokePoints = listOf(MaskPoint(offset.x, offset.y)) },
                        onDragEnd = {
                            if (liveStrokePoints.isNotEmpty()) {
                                state.strokes.add(BrushStroke(liveStrokePoints, state.brushRadiusPx))
                            }
                            liveStrokePoints = emptyList()
                        },
                        onDragCancel = { liveStrokePoints = emptyList() },
                        onDrag = { change, _ ->
                            change.consume()
                            liveStrokePoints = liveStrokePoints + MaskPoint(change.position.x, change.position.y)
                        },
                    )
                } else {
                    detectDragGestures(
                        onDragStart = { offset -> liveRectStart = offset; liveRectEnd = offset },
                        onDragEnd = {
                            val start = liveRectStart
                            val end = liveRectEnd
                            if (start != null && end != null) {
                                val candidate = MaskRect(start.x, start.y, end.x, end.y).normalized()
                                if (candidate.width > 6f && candidate.height > 6f) {
                                    state.rect = candidate
                                }
                            }
                            liveRectStart = null
                            liveRectEnd = null
                        },
                        onDragCancel = { liveRectStart = null; liveRectEnd = null },
                        onDrag = { change, _ ->
                            change.consume()
                            liveRectEnd = change.position
                        },
                    )
                }
            },
    ) {
        // Committed brush strokes
        for (stroke in state.strokes) {
            for (p in stroke.points) {
                drawCircle(color = MaskOverlay, radius = stroke.radiusPx, center = Offset(p.x, p.y))
            }
        }
        // In-progress brush stroke
        if (liveStrokePoints.isNotEmpty()) {
            for (p in liveStrokePoints) {
                drawCircle(color = MaskOverlay, radius = state.brushRadiusPx, center = Offset(p.x, p.y))
            }
        }

        // Committed rectangle
        state.rect?.let { r ->
            drawRect(color = MaskOverlay, topLeft = Offset(r.left, r.top), size = Size(r.width, r.height))
            drawRect(
                color = MaskOverlay.copy(alpha = 1f),
                topLeft = Offset(r.left, r.top),
                size = Size(r.width, r.height),
                style = Stroke(width = 2.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f))),
            )
        }
        // In-progress rectangle
        val rs = liveRectStart; val re = liveRectEnd
        if (rs != null && re != null) {
            val r = MaskRect(rs.x, rs.y, re.x, re.y).normalized()
            drawRect(color = MaskOverlay, topLeft = Offset(r.left, r.top), size = Size(r.width, r.height))
        }
    }
}

/** Converts a dp brush-size preset into the pixel radius MaskCanvasState expects. */
fun Dp.toRadiusPx(density: androidx.compose.ui.unit.Density): Float = with(density) { (this@toRadiusPx.toPx()) / 2f }
