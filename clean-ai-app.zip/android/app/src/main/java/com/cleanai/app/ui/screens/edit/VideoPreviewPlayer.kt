package com.cleanai.app.ui.screens.edit

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.cleanai.app.ui.components.PauseIcon
import com.cleanai.app.ui.components.PlayIcon
import com.cleanai.app.ui.theme.Accent

/**
 * A real, controllable video preview: our own small play/pause button
 * (matching the app's icon style) rather than ExoPlayer's default
 * controller overlay, since it needs to sit alongside the mask-drawing
 * canvas without visual clutter. RESIZE_MODE_FIT preserves the source
 * video's original aspect ratio (letterboxed, never cropped/stretched).
 */
@Composable
fun VideoPreviewPlayer(
    uri: Uri,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    var isPlaying by remember { mutableStateOf(false) }

    val exoPlayer = remember {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(uri))
            repeatMode = Player.REPEAT_MODE_ONE
            playWhenReady = false
            prepare()
        }
    }

    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
            exoPlayer.release()
        }
    }

    Box(modifier = modifier) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = false
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    setBackgroundColor(android.graphics.Color.TRANSPARENT)
                }
            },
        )

        val interactionSource = remember { MutableInteractionSource() }
        Box(
            modifier = Modifier
                .padding(12.dp)
                .align(Alignment.BottomStart)
                .size(44.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.92f))
                .clickable(interactionSource = interactionSource, indication = null) {
                    exoPlayer.playWhenReady = !exoPlayer.isPlaying
                },
            contentAlignment = Alignment.Center,
        ) {
            if (isPlaying) PauseIcon(color = Accent, size = 18.dp) else PlayIcon(color = Accent, size = 18.dp)
        }
    }
}
