package com.cleanai.app.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.cleanai.app.R
import com.cleanai.app.ui.components.ImageIcon
import com.cleanai.app.ui.components.MediaCard
import com.cleanai.app.ui.components.ShieldIcon
import com.cleanai.app.ui.components.SparkleIcon
import com.cleanai.app.ui.components.VideoIcon
import com.cleanai.app.ui.theme.Accent
import com.cleanai.app.ui.theme.Accent2
import com.cleanai.app.ui.theme.AppBackground
import com.cleanai.app.ui.theme.CardIconImageEnd
import com.cleanai.app.ui.theme.CardIconImageStart
import com.cleanai.app.ui.theme.CardIconVideoEnd
import com.cleanai.app.ui.theme.CardIconVideoStart
import com.cleanai.app.ui.theme.Ink
import com.cleanai.app.ui.theme.InkFaint
import com.cleanai.app.ui.theme.InkSoft

@Composable
fun HomeScreen(
    onCleanVideo: () -> Unit,
    onCleanImage: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AppBackground)
            .padding(horizontal = 24.dp)
            .padding(top = 22.dp, bottom = 22.dp),
    ) {
        // Brand row
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(11.dp))
                    .background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(Accent, Accent2))),
                contentAlignment = Alignment.Center,
            ) { SparkleIcon(color = Color.White, size = 18.dp) }

            Box(modifier = Modifier.size(10.dp))
            Text(stringResource(R.string.app_name), style = MaterialTheme.typography.titleLarge, color = Ink)
        }

        Box(modifier = Modifier.size(40.dp))

        // Heading
        Text(stringResource(R.string.home_heading), style = MaterialTheme.typography.headlineLarge, color = Ink)
        Box(modifier = Modifier.size(8.dp))
        Text(stringResource(R.string.home_subheading), style = MaterialTheme.typography.bodyLarge, color = InkSoft)

        Box(modifier = Modifier.size(32.dp))

        // Cards
        MediaCard(
            title = stringResource(R.string.home_card_video_title),
            description = stringResource(R.string.home_card_video_desc),
            iconGradientStart = CardIconVideoStart,
            iconGradientEnd = CardIconVideoEnd,
            icon = { VideoIcon(color = Color.White) },
            onClick = onCleanVideo,
        )
        Box(modifier = Modifier.size(14.dp))
        MediaCard(
            title = stringResource(R.string.home_card_image_title),
            description = stringResource(R.string.home_card_image_desc),
            iconGradientStart = CardIconImageStart,
            iconGradientEnd = CardIconImageEnd,
            icon = { ImageIcon(color = Color.White) },
            onClick = onCleanImage,
        )

        Column(
            modifier = Modifier.fillMaxWidth().weight(1f),
            verticalArrangement = Arrangement.Bottom,
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 26.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                ShieldIcon(color = InkFaint)
                Box(modifier = Modifier.size(7.dp))
                Text(stringResource(R.string.home_footer), color = InkFaint, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
