package com.cleanai.app.ui.screens.processing

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.cleanai.app.R
import com.cleanai.app.di.ServiceLocator
import com.cleanai.app.ui.CleanFlowViewModel
import com.cleanai.app.ui.JobPhase
import com.cleanai.app.ui.components.ErrorBanner
import com.cleanai.app.ui.components.PrimaryButton
import com.cleanai.app.ui.components.TextActionButton
import com.cleanai.app.ui.messageRes
import com.cleanai.app.ui.theme.Accent
import com.cleanai.app.ui.theme.Accent2
import com.cleanai.app.ui.theme.AppBackground
import com.cleanai.app.ui.theme.CanvasDark
import com.cleanai.app.ui.theme.CanvasDark2
import com.cleanai.app.ui.theme.Ink
import com.cleanai.app.ui.theme.InkSoft

@Composable
fun ProcessingScreen(
    viewModel: CleanFlowViewModel,
    onCompleted: () -> Unit,
    onBackToEdit: () -> Unit,
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    LaunchedEffect(uiState.jobPhase) {
        if (uiState.jobPhase == JobPhase.COMPLETED) onCompleted()
    }

    val isActive = uiState.jobPhase in setOf(
        JobPhase.PREPARING, JobPhase.UPLOADING, JobPhase.QUEUED, JobPhase.PROCESSING, JobPhase.DOWNLOADING,
    )
    val isFailed = uiState.jobPhase == JobPhase.FAILED
    val isCancelled = uiState.jobPhase == JobPhase.CANCELLED

    val animatedProgress by animateFloatAsState(targetValue = uiState.progress / 100f, label = "progress")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AppBackground)
            .padding(horizontal = 24.dp)
            .padding(top = 60.dp, bottom = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(28.dp))
                .background(Brush.linearGradient(listOf(CanvasDark, CanvasDark2))),
        ) {
            uiState.pickedFile?.let { picked ->
                AsyncImage(
                    model = picked.file,
                    imageLoader = ServiceLocator.imageLoader,
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize(),
                )
            }

            if (isActive) ScanLine(modifier = Modifier.fillMaxSize())

            Box(modifier = Modifier.align(Alignment.Center), contentAlignment = Alignment.Center) {
                if (!isFailed && !isCancelled) {
                    ProgressRing(progress = animatedProgress, modifier = Modifier.size(104.dp))
                    Text(
                        text = "${uiState.progress}%",
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium,
                    )
                }
            }
        }

        Spacer(Modifier.height(22.dp))

        when {
            isFailed -> {
                Text(stringResource(R.string.error_processing_failed), style = MaterialTheme.typography.headlineSmall, color = Ink, textAlign = TextAlign.Center)
                Spacer(Modifier.height(6.dp))
                ErrorBanner(message = uiState.error?.let { stringResource(it.messageRes()) })
                Spacer(Modifier.height(18.dp))
                PrimaryButton(text = stringResource(R.string.retry), onClick = { viewModel.retry(context) })
                Spacer(Modifier.height(10.dp))
                TextActionButton(text = stringResource(R.string.mark_different_area), onClick = onBackToEdit)
            }
            isCancelled -> {
                Text(stringResource(R.string.error_cancelled), style = MaterialTheme.typography.headlineSmall, color = Ink, textAlign = TextAlign.Center)
                Spacer(Modifier.height(18.dp))
                TextActionButton(text = stringResource(R.string.back), onClick = onBackToEdit)
            }
            else -> {
                Text(stringResource(R.string.cleaning_your_media), style = MaterialTheme.typography.headlineSmall, color = Ink, textAlign = TextAlign.Center)
                Spacer(Modifier.height(6.dp))
                Text(stringResource(R.string.processing_subtext), style = MaterialTheme.typography.bodyMedium, color = InkSoft, textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun ScanLine(modifier: Modifier = Modifier) {
    val infinite = rememberInfiniteTransition(label = "scan")
    val offsetFraction by infinite.animateFloat(
        initialValue = -0.15f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(tween(2100, easing = LinearEasing), repeatMode = RepeatMode.Restart),
        label = "scanOffset",
    )
    Canvas(modifier = modifier) {
        val bandHeight = size.height * 0.16f
        val y = offsetFraction * size.height
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color.Transparent, Accent.copy(alpha = 0.55f), Accent2.copy(alpha = 0.75f), Accent.copy(alpha = 0.55f), Color.Transparent),
                startY = y - bandHeight / 2,
                endY = y + bandHeight / 2,
            ),
            topLeft = Offset(0f, y - bandHeight / 2),
            size = Size(size.width, bandHeight),
        )
    }
}

@Composable
private fun ProgressRing(progress: Float, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val strokeWidth = size.minDimension * 0.06f
        drawArc(
            color = Color.White.copy(alpha = 0.16f),
            startAngle = -90f,
            sweepAngle = 360f,
            useCenter = false,
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = strokeWidth, cap = androidx.compose.ui.graphics.StrokeCap.Round),
        )
        drawArc(
            brush = Brush.linearGradient(listOf(Accent2, Color(0xFF8C7CFF))),
            startAngle = -90f,
            sweepAngle = 360f * progress,
            useCenter = false,
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = strokeWidth, cap = androidx.compose.ui.graphics.StrokeCap.Round),
        )
    }
}
