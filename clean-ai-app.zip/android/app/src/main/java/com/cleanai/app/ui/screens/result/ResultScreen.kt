package com.cleanai.app.ui.screens.result

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.cleanai.app.R
import com.cleanai.app.data.model.MediaType
import com.cleanai.app.di.ServiceLocator
import com.cleanai.app.ui.CleanFlowViewModel
import com.cleanai.app.ui.components.BottomToast
import com.cleanai.app.ui.components.CheckIcon
import com.cleanai.app.ui.components.DownloadIcon
import com.cleanai.app.ui.components.ErrorBanner
import com.cleanai.app.ui.components.PrimaryButton
import com.cleanai.app.ui.components.TextActionButton
import com.cleanai.app.ui.messageRes
import com.cleanai.app.ui.screens.edit.VideoPreviewPlayer
import com.cleanai.app.ui.theme.Accent
import com.cleanai.app.ui.theme.AppBackground
import com.cleanai.app.ui.theme.CanvasDark
import com.cleanai.app.ui.theme.CanvasDark2
import com.cleanai.app.ui.theme.Ink
import com.cleanai.app.ui.theme.InkSoft
import com.cleanai.app.ui.theme.Success
import kotlinx.coroutines.delay

@Composable
fun ResultScreen(
    viewModel: CleanFlowViewModel,
    onCleanAnother: () -> Unit,
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val mediaType = uiState.mediaType ?: MediaType.IMAGE
    var showToast by remember { mutableStateOf(false) }

    LaunchedEffect(uiState.savedEvent) {
        if (uiState.savedEvent > 0) {
            showToast = true
            delay(2400)
            showToast = false
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(AppBackground)
                .padding(horizontal = 24.dp)
                .padding(top = 26.dp, bottom = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(
                modifier = Modifier.size(52.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Success, Color(0xFF17A575)))),
                contentAlignment = Alignment.Center,
            ) { CheckIcon(color = Color.White, size = 24.dp) }

            Spacer(Modifier.height(14.dp))
            Text(stringResource(R.string.media_ready), style = MaterialTheme.typography.headlineSmall, color = Ink, textAlign = TextAlign.Center)
            Spacer(Modifier.height(6.dp))
            Text(stringResource(R.string.result_subtext), style = MaterialTheme.typography.bodyMedium, color = InkSoft, textAlign = TextAlign.Center)

            Spacer(Modifier.height(8.dp))
            ErrorBanner(message = uiState.error?.let { stringResource(it.messageRes()) })

            Spacer(Modifier.height(12.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(28.dp))
                    .background(Brush.linearGradient(listOf(CanvasDark, CanvasDark2))),
            ) {
                uiState.resultFile?.let { resultFile ->
                    if (mediaType == MediaType.VIDEO) {
                        VideoPreviewPlayer(uri = Uri.fromFile(resultFile), modifier = Modifier.fillMaxSize())
                    } else {
                        AsyncImage(
                            model = resultFile,
                            imageLoader = ServiceLocator.imageLoader,
                            contentDescription = null,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize(),
                        )
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
            PrimaryButton(
                text = stringResource(R.string.save_to_gallery),
                enabled = uiState.resultFile != null,
                onClick = { viewModel.saveToGallery(context) },
                leadingIcon = { DownloadIcon(color = Color.White, modifier = Modifier.padding(end = 8.dp)) },
            )
            Spacer(Modifier.height(6.dp))
            TextActionButton(
                text = stringResource(R.string.clean_another),
                color = Accent,
                onClick = {
                    viewModel.resetFlow()
                    onCleanAnother()
                },
            )
        }

        BottomToast(
            message = stringResource(R.string.saved_to_gallery),
            visible = showToast,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 96.dp),
        )
    }
}
