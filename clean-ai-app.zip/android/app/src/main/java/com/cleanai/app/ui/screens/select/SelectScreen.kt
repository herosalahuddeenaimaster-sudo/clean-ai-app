package com.cleanai.app.ui.screens.select

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.cleanai.app.R
import com.cleanai.app.data.model.MediaType
import com.cleanai.app.di.ServiceLocator
import com.cleanai.app.ui.CleanFlowViewModel
import com.cleanai.app.ui.components.ChevronRightIcon
import com.cleanai.app.ui.components.ErrorBanner
import com.cleanai.app.ui.components.ImageIcon
import com.cleanai.app.ui.components.PlayIcon
import com.cleanai.app.ui.components.PlusIcon
import com.cleanai.app.ui.components.PrimaryButton
import com.cleanai.app.ui.components.ScreenHeader
import com.cleanai.app.ui.components.VideoIcon
import com.cleanai.app.ui.messageRes
import com.cleanai.app.ui.theme.Accent
import com.cleanai.app.ui.theme.Accent2
import com.cleanai.app.ui.theme.AccentSoft
import com.cleanai.app.ui.theme.AppBackground
import com.cleanai.app.ui.theme.CanvasDark
import com.cleanai.app.ui.theme.Ink
import com.cleanai.app.ui.theme.InkFaint
import com.cleanai.app.ui.theme.InkSoft
import com.cleanai.app.ui.theme.Surface
import com.cleanai.app.util.UriFileUtils
import kotlinx.coroutines.launch

@Composable
fun SelectScreen(
    viewModel: CleanFlowViewModel,
    onBack: () -> Unit,
    onContinue: () -> Unit,
) {
    val uiState by viewModel.uiState.collectAsState()
    val mediaType = uiState.mediaType ?: MediaType.IMAGE
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var isPicking by remember { mutableStateOf(false) }

    val pickerLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            isPicking = true
            scope.launch {
                viewModel.onMediaPicked(context, uri)
                isPicking = false
            }
        }
    }

    fun launchPicker() {
        val request = PickVisualMediaRequest(
            mediaType = if (mediaType == MediaType.VIDEO) {
                ActivityResultContracts.PickVisualMedia.VideoOnly
            } else {
                ActivityResultContracts.PickVisualMedia.ImageOnly
            },
        )
        pickerLauncher.launch(request)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AppBackground)
            .padding(horizontal = 24.dp)
            .padding(top = 14.dp, bottom = 22.dp),
    ) {
        ScreenHeader(
            title = stringResource(if (mediaType == MediaType.VIDEO) R.string.home_card_video_title else R.string.home_card_image_title),
            onBack = onBack,
        )

        Spacer(Modifier.height(22.dp))
        Text(
            stringResource(if (mediaType == MediaType.VIDEO) R.string.select_heading_video else R.string.select_heading_image),
            style = MaterialTheme.typography.headlineMedium,
            color = Ink,
        )
        Spacer(Modifier.height(6.dp))
        Text(
            stringResource(if (mediaType == MediaType.VIDEO) R.string.select_subtext_video else R.string.select_subtext_image),
            style = MaterialTheme.typography.bodyLarge,
            color = InkSoft,
        )

        Spacer(Modifier.height(16.dp))
        ErrorBanner(message = uiState.error?.let { stringResource(it.messageRes()) })
        Spacer(Modifier.height(8.dp))

        if (uiState.pickedFile == null) {
            Dropzone(
                mediaType = mediaType,
                loading = isPicking,
                onClick = { if (!isPicking) launchPicker() },
                modifier = Modifier.weight(1f),
            )
        } else {
            Column(modifier = Modifier.weight(1f)) {
                SelectedPreviewCard(
                    mediaType = mediaType,
                    fileName = uiState.pickedFile!!.displayName,
                    fileSizeLabel = UriFileUtils.formatBytes(uiState.pickedFile!!.sizeBytes),
                    fileUri = uiState.pickedFile!!.file,
                    onChange = { launchPicker() },
                )
                Spacer(Modifier.height(16.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(28.dp))
                        .background(CanvasDark),
                    contentAlignment = Alignment.Center,
                ) {
                    AsyncImage(
                        model = uiState.pickedFile!!.file,
                        imageLoader = ServiceLocator.imageLoader,
                        contentDescription = null,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
                Spacer(Modifier.height(18.dp))
                PrimaryButton(
                    text = stringResource(R.string.continue_label),
                    onClick = onContinue,
                )
            }
        }
    }
}

@Composable
private fun Dropzone(
    mediaType: MediaType,
    loading: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val interactionSource = remember { MutableInteractionSource() }
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(Surface)
            .border(1.6.dp, Color(0xFFD4D0E8), RoundedCornerShape(28.dp))
            .clickable(interactionSource = interactionSource, indication = null, onClick = onClick)
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            modifier = Modifier.size(64.dp).clip(RoundedCornerShape(20.dp)).background(AccentSoft),
            contentAlignment = Alignment.Center,
        ) {
            if (mediaType == MediaType.VIDEO) VideoIcon(color = Accent) else ImageIcon(color = Accent)
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .size(22.dp)
                    .clip(CircleShape)
                    .background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(Accent, Accent2))),
                contentAlignment = Alignment.Center,
            ) { PlusIcon(color = Color.White) }
        }

        Spacer(Modifier.height(14.dp))

        if (loading) {
            CircularProgressIndicator(color = Accent, modifier = Modifier.size(28.dp), strokeWidth = 3.dp)
        } else {
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(15.dp))
                    .background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(Accent, Accent2)))
                    .padding(horizontal = 26.dp, vertical = 15.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(stringResource(R.string.choose_from_gallery), color = Color.White, style = MaterialTheme.typography.labelMedium)
            }
        }

        Spacer(Modifier.height(10.dp))
        Text(
            stringResource(if (mediaType == MediaType.VIDEO) R.string.caption_video_limits else R.string.caption_image_limits),
            color = InkFaint,
            style = MaterialTheme.typography.bodySmall,
        )
    }
}

@Composable
private fun SelectedPreviewCard(
    mediaType: MediaType,
    fileName: String,
    fileSizeLabel: String,
    fileUri: java.io.File,
    onChange: () -> Unit,
) {
    val interactionSource = remember { MutableInteractionSource() }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Surface)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier.size(64.dp).clip(RoundedCornerShape(14.dp)).background(CanvasDark),
            contentAlignment = Alignment.Center,
        ) {
            AsyncImage(
                model = fileUri,
                imageLoader = ServiceLocator.imageLoader,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
            if (mediaType == MediaType.VIDEO) {
                Box(
                    modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center,
                ) { PlayIcon(color = Color.White, size = 18.dp) }
            }
        }

        Spacer(Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(fileName, style = MaterialTheme.typography.titleSmall, color = Ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(2.dp))
            Text(fileSizeLabel, style = MaterialTheme.typography.bodySmall, color = InkSoft)
        }

        Spacer(Modifier.width(8.dp))
        Text(
            stringResource(R.string.change),
            color = Accent,
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.clickable(interactionSource = interactionSource, indication = null, onClick = onChange),
        )
    }
}
