package com.cleanai.app.ui.theme

import androidx.compose.ui.graphics.Color

// Ported 1:1 from the prototype's CSS custom properties (--bg, --surface, etc.)
val AppBackground = Color(0xFFF8F7FC)
val Surface = Color(0xFFFFFFFF)
val CanvasDark = Color(0xFF121120)
val CanvasDark2 = Color(0xFF1B1930)

val Ink = Color(0xFF17162B)
val InkSoft = Color(0xFF6E6C86)
val InkFaint = Color(0xFFA5A3BC)

val Accent = Color(0xFF6C5CE7)
val Accent2 = Color(0xFF4A63F2)
val AccentSoft = Color(0xFFEFECFD)

val Line = Color(0xFFEAE8F3)
val Success = Color(0xFF20B587)
val Danger = Color(0xFFEF5A5A)

val CardIconVideoStart = Color(0xFF7E6CF0)
val CardIconVideoEnd = Color(0xFF5B49D9)
val CardIconImageStart = Color(0xFF5E82FF)
val CardIconImageEnd = Color(0xFF3E58E8)

val MaskOverlay = Color(0x616C5CE7) // rgba(108,92,231,0.38) used for the drawn mask paint
