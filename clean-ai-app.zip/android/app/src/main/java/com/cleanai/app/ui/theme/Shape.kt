package com.cleanai.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

val RadiusLg = RoundedCornerShape(28.dp)
val RadiusMd = RoundedCornerShape(20.dp)
val RadiusSm = RoundedCornerShape(14.dp)
val RadiusPill = RoundedCornerShape(50)
