package com.cleanai.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val CleanAiColorScheme = lightColorScheme(
    primary = Accent,
    onPrimary = Surface,
    secondary = Accent2,
    background = AppBackground,
    surface = Surface,
    onBackground = Ink,
    onSurface = Ink,
    error = Danger,
)

private val CleanAiShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp),
    small = RadiusSm,
    medium = RadiusMd,
    large = RadiusLg,
    extraLarge = RoundedCornerShape(32.dp),
)

@Composable
fun CleanAiTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = CleanAiColorScheme,
        typography = AppTypography,
        shapes = CleanAiShapes,
        content = content,
    )
}
