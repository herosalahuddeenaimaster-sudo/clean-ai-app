package com.cleanai.app.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * The prototype uses "Plus Jakarta Sans" for headings/buttons and "Inter"
 * for body text (both loaded from Google Fonts in the browser). Neither
 * can be bundled here as a binary .ttf, and I'm not going to fabricate
 * the certificate hashes a Downloadable-Fonts XML needs — that's the
 * kind of thing that fails silently and confusingly if it's wrong.
 *
 * To get pixel-identical typefaces:
 *   Option A (no internet needed): drop the real .ttf/.otf files into
 *     res/font/ and point HeadlineFont / BodyFont at them.
 *   Option B: in Android Studio, right-click res/font → New → Font
 *     Resource → search "Plus Jakarta Sans" / "Inter" → Android Studio
 *     generates the correct provider XML + cert array for you.
 *
 * Until then, this falls back to the platform's default sans-serif,
 * which keeps every size/weight/spacing decision from the design intact
 * — only the exact letterforms differ.
 */
val HeadlineFont = FontFamily.SansSerif
val BodyFont = FontFamily.SansSerif

val AppTypography = Typography(
    // Screen headlines ("Clean Your Media", "Your media is ready!")
    headlineLarge = TextStyle(fontFamily = HeadlineFont, fontWeight = FontWeight.ExtraBold, fontSize = 29.sp, lineHeight = 34.sp, letterSpacing = (-0.4).sp),
    headlineMedium = TextStyle(fontFamily = HeadlineFont, fontWeight = FontWeight.ExtraBold, fontSize = 23.sp, lineHeight = 28.sp, letterSpacing = (-0.3).sp),
    headlineSmall = TextStyle(fontFamily = HeadlineFont, fontWeight = FontWeight.ExtraBold, fontSize = 21.sp, lineHeight = 26.sp, letterSpacing = (-0.2).sp),

    // Screen titles in headers, card titles
    titleLarge = TextStyle(fontFamily = HeadlineFont, fontWeight = FontWeight.Bold, fontSize = 19.sp, lineHeight = 24.sp),
    titleMedium = TextStyle(fontFamily = HeadlineFont, fontWeight = FontWeight.Bold, fontSize = 17.sp, lineHeight = 22.sp),
    titleSmall = TextStyle(fontFamily = HeadlineFont, fontWeight = FontWeight.Bold, fontSize = 16.5.sp, lineHeight = 21.sp),

    // Buttons
    labelLarge = TextStyle(fontFamily = HeadlineFont, fontWeight = FontWeight.Bold, fontSize = 16.sp, letterSpacing = (-0.1).sp),
    labelMedium = TextStyle(fontFamily = HeadlineFont, fontWeight = FontWeight.Bold, fontSize = 14.5.sp),
    labelSmall = TextStyle(fontFamily = HeadlineFont, fontWeight = FontWeight.SemiBold, fontSize = 13.sp),

    // Body copy
    bodyLarge = TextStyle(fontFamily = BodyFont, fontWeight = FontWeight.Normal, fontSize = 14.5.sp, lineHeight = 21.sp),
    bodyMedium = TextStyle(fontFamily = BodyFont, fontWeight = FontWeight.Normal, fontSize = 13.5.sp, lineHeight = 19.sp),
    bodySmall = TextStyle(fontFamily = BodyFont, fontWeight = FontWeight.Medium, fontSize = 12.5.sp, lineHeight = 17.sp),
)
