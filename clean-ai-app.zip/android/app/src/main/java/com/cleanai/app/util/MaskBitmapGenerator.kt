package com.cleanai.app.util

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.cleanai.app.domain.MaskDraft
import com.cleanai.app.domain.MaskTool
import java.io.File
import java.io.FileOutputStream

/**
 * Same "object-fit: contain" math the click-through prototype used in the
 * browser: the media is shown letterboxed inside the preview box, so a
 * point drawn on screen has to be translated through that same scale +
 * offset before it means anything in the source image/video's own pixel
 * space.
 */
data class ContainFit(val scale: Float, val offsetX: Float, val offsetY: Float)

fun computeContainFit(naturalW: Int, naturalH: Int, boxW: Float, boxH: Float): ContainFit {
    val scale = minOf(boxW / naturalW, boxH / naturalH)
    val dispW = naturalW * scale
    val dispH = naturalH * scale
    return ContainFit(scale = scale, offsetX = (boxW - dispW) / 2f, offsetY = (boxH - dispH) / 2f)
}

object MaskBitmapGenerator {

    /**
     * Renders [draft] (drawn in on-screen pixel coordinates, inside a box
     * of size [boxWidth] x [boxHeight]) into a black/white PNG sized to
     * the source media's [naturalWidth] x [naturalHeight]. White = "remove
     * this area", black = "keep". Written to [outputFile].
     *
     * Returns false if the draft was empty (nothing to remove) — callers
     * should treat that as "no mask to send".
     */
    fun renderToFile(
        draft: MaskDraft,
        boxWidth: Float,
        boxHeight: Float,
        naturalWidth: Int,
        naturalHeight: Int,
        outputFile: File,
    ): Boolean {
        if (draft.isEmpty || naturalWidth <= 0 || naturalHeight <= 0) return false

        val fit = computeContainFit(naturalWidth, naturalHeight, boxWidth, boxHeight)
        val bitmap = Bitmap.createBitmap(naturalWidth, naturalHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.BLACK)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }

        fun toNaturalX(x: Float) = (x - fit.offsetX) / fit.scale
        fun toNaturalY(y: Float) = (y - fit.offsetY) / fit.scale

        when (draft.tool) {
            MaskTool.BRUSH -> {
                for (stroke in draft.strokes) {
                    val naturalRadius = stroke.radiusPx / fit.scale
                    for (p in stroke.points) {
                        canvas.drawCircle(toNaturalX(p.x), toNaturalY(p.y), naturalRadius, paint)
                    }
                }
            }
            MaskTool.RECTANGLE -> {
                draft.rect?.normalized()?.let { r ->
                    canvas.drawRect(
                        toNaturalX(r.left), toNaturalY(r.top),
                        toNaturalX(r.right), toNaturalY(r.bottom),
                        paint,
                    )
                }
            }
        }

        FileOutputStream(outputFile).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        bitmap.recycle()
        return true
    }
}
