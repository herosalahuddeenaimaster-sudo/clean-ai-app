package com.cleanai.app.util

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.cleanai.app.data.model.MediaType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object MediaStoreSaver {

    private const val ALBUM_NAME = "Clean AI"

    /**
     * Copies [sourceFile] into the appropriate MediaStore collection
     * (Pictures/Clean AI or Movies/Clean AI) so it shows up in the
     * user's normal gallery app. Returns the resulting content Uri.
     *
     * - Android 10+ (API 29+): scoped storage, no extra permission needed
     *   for files the app creates itself. Uses IS_PENDING to avoid the
     *   file appearing half-written in the gallery.
     * - Android 9 and below (API 26-28): relies on the
     *   WRITE_EXTERNAL_STORAGE permission declared with
     *   android:maxSdkVersion="28" in the manifest.
     */
    suspend fun saveToGallery(context: Context, sourceFile: File, mediaType: MediaType, mimeType: String, displayName: String): Uri =
        withContext(Dispatchers.IO) {
            val resolver = context.contentResolver
            val collection: Uri
            val values = ContentValues()

            if (mediaType == MediaType.IMAGE) {
                collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                } else {
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                }
                values.put(MediaStore.Images.Media.DISPLAY_NAME, displayName)
                values.put(MediaStore.Images.Media.MIME_TYPE, mimeType)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    values.put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/$ALBUM_NAME")
                    values.put(MediaStore.Images.Media.IS_PENDING, 1)
                }
            } else {
                collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                } else {
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                }
                values.put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
                values.put(MediaStore.Video.Media.MIME_TYPE, mimeType)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    values.put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/$ALBUM_NAME")
                    values.put(MediaStore.Video.Media.IS_PENDING, 1)
                }
            }

            val itemUri = resolver.insert(collection, values)
                ?: error("MediaStore did not return a Uri for the new item")

            resolver.openOutputStream(itemUri)?.use { out ->
                sourceFile.inputStream().use { input -> input.copyTo(out) }
            } ?: error("Could not open output stream for $itemUri")

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(itemUri, values, null, null)
            }

            itemUri
        }
}
