package com.cleanai.app.util

import android.content.Context
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

data class PickedFileInfo(
    val file: File,
    val displayName: String,
    val mimeType: String,
    val sizeBytes: Long,
)

object UriFileUtils {

    /** Copies the content:// Uri's bytes into this app's cache dir so we have a real File to upload. */
    suspend fun copyToCache(context: Context, uri: Uri, subDir: String): PickedFileInfo = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val mimeType = resolver.getType(uri) ?: guessMimeFromUri(uri) ?: "application/octet-stream"
        val displayName = queryDisplayName(context, uri) ?: "media_${System.currentTimeMillis()}"

        val dir = File(context.cacheDir, subDir).apply { mkdirs() }
        val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mimeType)
        val safeName = if (ext != null && !displayName.endsWith(".$ext")) "$displayName.$ext" else displayName
        val outFile = File(dir, "${System.currentTimeMillis()}_$safeName")

        resolver.openInputStream(uri)?.use { input ->
            FileOutputStream(outFile).use { output -> input.copyTo(output) }
        } ?: error("Could not open input stream for $uri")

        PickedFileInfo(
            file = outFile,
            displayName = displayName,
            mimeType = mimeType,
            sizeBytes = outFile.length(),
        )
    }

    private fun queryDisplayName(context: Context, uri: Uri): String? {
        return context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) cursor.getString(idx) else null
            } else null
        }
    }

    private fun guessMimeFromUri(uri: Uri): String? {
        val ext = MimeTypeMap.getFileExtensionFromUrl(uri.toString())
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
    }

    /** Decodes just the bounds — cheap, doesn't load full pixel data. */
    fun readImageDimensions(file: File): Pair<Int, Int> {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, opts)
        return opts.outWidth to opts.outHeight
    }

    /** Returns (width, height, durationMs). Any value may be 0 if the retriever couldn't read it. */
    fun readVideoMetadata(file: File): Triple<Int, Int, Long> {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(file.absolutePath)
            val w = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val h = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            // Rotated 90/270 video reports width/height un-rotated — swap for correct aspect ratio.
            if (rotation == 90 || rotation == 270) Triple(h, w, duration) else Triple(w, h, duration)
        } catch (e: Exception) {
            Triple(0, 0, 0L)
        } finally {
            retriever.release()
        }
    }

    fun formatBytes(bytes: Long): String {
        if (bytes < 1024 * 1024) return "${maxOf(1, bytes / 1024)} KB"
        return String.format("%.1f MB", bytes / (1024.0 * 1024.0))
    }
}
