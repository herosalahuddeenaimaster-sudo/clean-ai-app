# Clean AI — Backend

Secure backend for the Clean AI Android app. The app never talks to an AI
vendor directly — it only talks to this service over HTTPS, and this
service talks to a swappable AI provider (mock by default, or real
fal.ai models once you add a key).

```
Android App → HTTPS → This Backend → AI Provider (mock or fal.ai) → Temp storage → Backend → Android App
```

## Run locally

```bash
cd backend
cp .env.example .env      # already done if you're using the checked-in .env
npm install
npm start                 # or: npm run dev  (auto-restarts on file changes)
```

Server starts on `http://localhost:8080` by default. `AI_PROVIDER=mock`
out of the box, so nothing here ever calls a paid API until you
explicitly switch it — see [Using real fal.ai processing](#using-real-falai-processing)
below.

`npm install` also pulls in `@ffmpeg-installer/ffmpeg` and
`@ffprobe-installer/ffprobe`, which bundle a static ffmpeg/ffprobe binary
for your OS — no separate system install of ffmpeg is required.

> This project was scaffolded in a sandboxed environment without npm
> registry access, so `npm install` hasn't been run or verified end-to-end
> here. The code is written and reviewed carefully, but run it locally and
> watch the console for any dependency hiccups before shipping.

## API

| Method | Path                     | Purpose                                             |
|--------|--------------------------|------------------------------------------------------|
| GET    | `/api/health`            | Liveness check                                       |
| POST   | `/api/upload`             | Upload a media file or mask (`multipart/form-data`, field `file`) |
| POST   | `/api/jobs`               | Create a processing job from two uploaded file ids    |
| GET    | `/api/jobs/:jobId`        | Poll job status/progress                              |
| GET    | `/api/jobs/:jobId/result` | Download the finished file once `status = completed`  |
| DELETE | `/api/jobs/:jobId`        | Cancel a queued/processing job                        |

### Typical flow

```bash
# 1. Upload the source image
curl -F "file=@photo.jpg" http://localhost:8080/api/upload
# -> { "fileId": "abc-123", "kind": "image", ... }

# 2. Upload the mask (white = remove, black = keep, same dimensions as source)
curl -F "file=@mask.png" http://localhost:8080/api/upload
# -> { "fileId": "def-456", "kind": "mask", ... }

# 3. Create the job
curl -X POST http://localhost:8080/api/jobs \
  -H "Content-Type: application/json" \
  -d '{"mediaFileId":"abc-123","maskFileId":"def-456","mediaType":"image"}'
# -> { "jobId": "job-789", "status": "queued", ... }

# 4. Poll until status is "completed" or "failed"
curl http://localhost:8080/api/jobs/job-789

# 5. Download the result
curl http://localhost:8080/api/jobs/job-789/result -o cleaned.jpg
```

## Project layout

```
src/
  index.js              Express app entry point
  config.js             Reads all config from env vars (see .env.example)
  logger.js              Tiny structured console logger
  errors/ApiError.js     Typed error -> consistent JSON error responses
  middleware/            errorHandler, notFound
  routes/                upload, jobs, health — thin, validate + delegate
  services/
    fileStore.js          In-memory registry of uploaded files
    jobStore.js            In-memory registry of processing jobs
    jobQueue.js             Sequential worker loop that calls the provider
    cleanupService.js       Periodic deletion of expired temp files
    fileValidation.js       Mime-type / size-limit rules
    storage.js               Local-disk storage bootstrap
    videoMaskGenerator.js     Loops a static mask image into a mask video (ffmpeg)
  providers/
    AIProvider.js            Interface every provider implements
    MockProvider.js           Local simulation (sharp-based clone-stamp for images)
    FalProvider.js             Real fal.ai integration (see below)
    index.js                   Factory: picks provider from AI_PROVIDER env var
```

## Using real fal.ai processing

Set `AI_PROVIDER=fal` and `FAL_KEY=<your key>` in `.env` (get a key from
[fal.ai/dashboard/keys](https://fal.ai/dashboard/keys)). `FalProvider.js`
then calls two real fal.ai models:

| Media | Model | Input | Notes |
|-------|-------|-------|-------|
| Image | [`fal-ai/object-removal/mask`](https://fal.ai/models/fal-ai/object-removal/mask) | `image_url`, `mask_url` | Mask convention: **white = remove**, same as this app's own mask generator — sent as-is, no conversion. |
| Video | [`fal-ai/void-video-inpainting`](https://fal.ai/models/fal-ai/void-video-inpainting) | `video_url`, `quad_mask_video_url`, `prompt` | Mask convention: **black = remove** — the *opposite* of the image model. `FalProvider.js` inverts the mask before use. `prompt` is required by the model but this app's UI never collects one, so a generic "restore the original background" prompt is sent automatically. |

Both `image_url`/`video_url`-style fields accept a Base64 data URI
directly, which is what's used for images. Video files are uploaded to
fal's own file storage first (`fal.storage.upload`) since they're too
large to comfortably inline as base64.

**Video mask caveat**: the app's mask tool draws one static region on a
single frame. For video, that single mask is looped into a same-duration
mask video (via ffmpeg) — meaning it treats the marked area as
stationary for the whole clip. This works well for a fixed object
(a sign, a logo, a stationary person) but won't track a moving subject;
real per-frame tracking would need a video segmentation model, which is
a separate feature, not a bug in this integration.

**Cost awareness**: every real call costs money (fal.ai's own pricing
page has current rates — void-video-inpainting was $0.05–$0.15/video at
time of writing). Mock mode has zero cost and is the safe default;
switch to `fal` deliberately, and consider gating it behind your own
usage limits before exposing it publicly.

## Adding a different AI provider later

1. Copy the shape of `FalProvider.js` (implements `AIProvider.process()`),
   swap in your vendor's real endpoints and parameters — read their
   actual docs, don't guess.
2. Add a new branch in `providers/index.js`'s `getProvider()` for your
   provider's `AI_PROVIDER` value.
3. Nothing else changes — routes, the queue, and the Android app are all
   already written against the provider-agnostic job API above.

## Notes on the in-memory stores

`fileStore` and `jobStore` are `Map`s in process memory — intentional for
an MVP/mock deployment. For production:
- Swap them for a real database (Postgres/Redis) so multiple backend
  instances can share state.
- Swap `services/storage.js`'s local-disk reads/writes for S3/GCS calls.
- Swap `jobQueue.js`'s internals for BullMQ + Redis (or SQS/Cloud Tasks)
  for real concurrency and durability across restarts.

None of those changes touch `routes/` or `providers/` — that separation
is the point.

## Security notes

- `FAL_KEY` (or any provider key) is only ever read from environment
  variables, never hard-coded, and never sent to the Android app.
- Uploaded/result files are deleted automatically after
  `FILE_RETENTION_MINUTES` (default 60).
- Upload size and mime type are validated server-side, not just trusted
  from the client.
