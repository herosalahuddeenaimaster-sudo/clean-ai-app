/**
 * A predictable, serializable error for anything the client should see a
 * clean message for (bad upload, unsupported file, missing job, etc).
 * Anything that is NOT an ApiError is treated as an unexpected server
 * error and gets a generic message so internals never leak to clients.
 */
class ApiError extends Error {
  constructor(statusCode, code, message) {
    super(message);
    this.name = 'ApiError';
    this.statusCode = statusCode;
    this.code = code;
  }

  static badRequest(code, message) {
    return new ApiError(400, code, message);
  }
  static notFound(code, message) {
    return new ApiError(404, code, message);
  }
  static payloadTooLarge(code, message) {
    return new ApiError(413, code, message);
  }
  static unsupportedMedia(code, message) {
    return new ApiError(415, code, message);
  }
  static conflict(code, message) {
    return new ApiError(409, code, message);
  }
  static internal(code, message) {
    return new ApiError(500, code, message);
  }
}

module.exports = ApiError;
