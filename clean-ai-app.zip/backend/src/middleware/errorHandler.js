const multer = require('multer');
const ApiError = require('../errors/ApiError');
const logger = require('../logger');

/**
 * Express error-handling middleware (4 args = special signature Express
 * recognizes). Keeps error responses in one predictable shape so the
 * Android app can branch on `error.code` instead of parsing prose.
 */
// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  if (err instanceof ApiError) {
    if (err.statusCode >= 500) logger.error(err.code, err.message, err.stack);
    else logger.warn(err.code, err.message);

    return res.status(err.statusCode).json({
      error: { code: err.code, message: err.message },
    });
  }

  if (err instanceof multer.MulterError) {
    const code = err.code === 'LIMIT_FILE_SIZE' ? 'FILE_TOO_LARGE' : 'UPLOAD_ERROR';
    const status = err.code === 'LIMIT_FILE_SIZE' ? 413 : 400;
    logger.warn('multer', err.code, err.message);
    return res.status(status).json({ error: { code, message: err.message } });
  }

  // Unexpected error — never leak internals to the client.
  logger.error('UNEXPECTED', err && err.stack ? err.stack : err);
  return res.status(500).json({
    error: { code: 'INTERNAL_ERROR', message: 'Something went wrong. Please try again.' },
  });
}

module.exports = errorHandler;
