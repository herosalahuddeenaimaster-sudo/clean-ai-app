/**
 * Contract every AI provider must implement. Routes and the job queue
 * only ever talk to this interface — never to a specific vendor's SDK
 * or HTTP API directly. That means switching providers later is a
 * one-file change (providers/index.js) plus a new class here.
 *
 * @typedef {Object} ProcessInput
 * @property {string} mediaPath     Absolute path to the source image/video on disk.
 * @property {string} maskPath      Absolute path to the mask PNG on disk.
 * @property {'image'|'video'} mediaType
 * @property {string} outputPath    Absolute path the provider should write its result to.
 * @property {(percent:number)=>void} onProgress  Call with 0-100 as work advances.
 *
 * @typedef {Object} ProcessResult
 * @property {string} resultPath      Absolute path to the finished file (usually === outputPath).
 * @property {string} resultMimeType  e.g. 'image/jpeg' or 'video/mp4'.
 */
class AIProvider {
  /**
   * @param {ProcessInput} input
   * @returns {Promise<ProcessResult>}
   */
  // eslint-disable-next-line no-unused-vars
  async process(input) {
    throw new Error('AIProvider.process() must be implemented by a subclass');
  }
}

module.exports = AIProvider;
