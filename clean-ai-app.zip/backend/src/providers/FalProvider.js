const fs = require('fs/promises');
const path = require('path');
const sharp = require('sharp');
const { File } = require('node:buffer');

const AIProvider = require('./AIProvider');
const config = require('../config');
const ApiError = require('../errors/ApiError');
const logger = require('../logger');
const { generateStaticMaskVideo } = require('../services/videoMaskGenerator');

// A generic, honest default: the app's mask-only UI never collects a text
// description from the user, but void-video-inpainting requires a `prompt`
// describing the desired result. This asks for exactly what the product
// promises — the original scene, minus the marked object — without
// inventing content that isn't there.
const DEFAULT_BACKGROUND_PROMPT =
  'Seamlessly restore the original background exactly as it would appear with the marked object removed. Match the existing lighting, texture, and camera motion.';

/**
 * REAL fal.ai provider — verified against fal.ai's own current docs for
 * both models (input/output schema, field names, mask color convention)
 * rather than assumed from general knowledge. If fal.ai changes either
 * model's contract, this is the one file that needs updating.
 *
 * Models used:
 *   image -> fal-ai/object-removal/mask
 *            { image_url, mask_url } -> { images: [{ url, content_type }] }
 *            mask convention: WHITE (255) = remove, matches this app's own
 *            mask generator exactly — no conversion needed.
 *
 *   video -> fal-ai/void-video-inpainting
 *            { video_url, quad_mask_video_url, prompt } -> { video: { url } }
 *            mask convention: BLACK (0) = remove, WHITE (255) = keep — the
 *            OPPOSITE of this app's own mask and of the image model above.
 *            We invert the mask before building the mask video for this
 *            reason (see _processVideo).
 *
 * @fal-ai/client is loaded via a lazy dynamic import() rather than a plain
 * require() — this backend is written as CommonJS, and dynamic import()
 * is the one loading method guaranteed to work regardless of whether a
 * given npm package ships as CommonJS, ESM, or both.
 */
class FalProvider extends AIProvider {
  constructor() {
    super();
    if (!config.falKey) {
      throw ApiError.internal(
        'PROVIDER_NOT_CONFIGURED',
        'AI_PROVIDER=fal but FAL_KEY is not set. Get a key from https://fal.ai/dashboard/keys and set it in .env.'
      );
    }
    this._fal = null;
  }

  async _getFal() {
    if (!this._fal) {
      const mod = await import('@fal-ai/client');
      this._fal = mod.fal;
      // @fal-ai/client reads FAL_KEY from the environment automatically,
      // but configuring explicitly means it still works even if some other
      // part of the process environment gets sanitized before this loads.
      this._fal.config({ credentials: config.falKey });
    }
    return this._fal;
  }

  async process(input) {
    if (input.mediaType === 'video') return this._processVideo(input);
    return this._processImage(input);
  }

  // ------------------------------------------------------------
  // Image: fal-ai/object-removal/mask
  // ------------------------------------------------------------
  async _processImage({ mediaPath, maskPath, outputPath, onProgress }) {
    const fal = await this._getFal();
    onProgress?.(10);

    // Re-encode through sharp so we always know the exact mime type we're
    // declaring in the data URI, regardless of the original upload format.
    const imageBuffer = await sharp(mediaPath).jpeg({ quality: 95 }).toBuffer();
    const maskBuffer = await fs.readFile(maskPath); // already PNG, white=remove — matches this model directly

    const imageDataUri = `data:image/jpeg;base64,${imageBuffer.toString('base64')}`;
    const maskDataUri = `data:image/png;base64,${maskBuffer.toString('base64')}`;
    onProgress?.(25);

    const result = await fal.subscribe('fal-ai/object-removal/mask', {
      input: {
        image_url: imageDataUri,
        mask_url: maskDataUri,
      },
      logs: true,
      onQueueUpdate: (update) => {
        if (update.status === 'IN_PROGRESS') onProgress?.(60);
      },
    });

    const image = result.data && result.data.images && result.data.images[0];
    if (!image || !image.url) {
      logger.error('fal.ai object-removal/mask returned no image', JSON.stringify(result.data));
      throw new Error('fal.ai object-removal/mask returned no image');
    }
    onProgress?.(85);

    await downloadToFile(image.url, outputPath);
    onProgress?.(97);

    return { resultPath: outputPath, resultMimeType: image.content_type || 'image/jpeg' };
  }

  // ------------------------------------------------------------
  // Video: fal-ai/void-video-inpainting
  // ------------------------------------------------------------
  async _processVideo({ mediaPath, maskPath, outputPath, onProgress }) {
    const fal = await this._getFal();
    onProgress?.(8);

    const invertedMaskPath = `${outputPath}.mask.png`;
    const maskVideoPath = `${outputPath}.mask.mp4`;

    try {
      // Invert: our mask is white=remove/black=keep; VOID's quad mask wants
      // the opposite (black=remove/white=keep). See class doc comment.
      await sharp(maskPath).negate({ alpha: false }).toFile(invertedMaskPath);
      onProgress?.(14);

      await generateStaticMaskVideo({
        maskImagePath: invertedMaskPath,
        referenceVideoPath: mediaPath,
        outputPath: maskVideoPath,
      });
      onProgress?.(24);

      const [videoUrl, maskVideoUrl] = await Promise.all([
        uploadLocalFile(fal, mediaPath, 'video/mp4'),
        uploadLocalFile(fal, maskVideoPath, 'video/mp4'),
      ]);
      onProgress?.(40);

      const result = await fal.subscribe('fal-ai/void-video-inpainting', {
        input: {
          video_url: videoUrl,
          quad_mask_video_url: maskVideoUrl,
          prompt: DEFAULT_BACKGROUND_PROMPT,
        },
        logs: true,
        onQueueUpdate: (update) => {
          if (update.status === 'IN_PROGRESS') onProgress?.(70);
        },
      });

      const video = result.data && result.data.video;
      if (!video || !video.url) {
        logger.error('fal.ai void-video-inpainting returned no video', JSON.stringify(result.data));
        throw new Error('fal.ai void-video-inpainting returned no video');
      }
      onProgress?.(90);

      await downloadToFile(video.url, outputPath);
      onProgress?.(97);

      return { resultPath: outputPath, resultMimeType: 'video/mp4' };
    } finally {
      await fs.unlink(invertedMaskPath).catch(() => {});
      await fs.unlink(maskVideoPath).catch(() => {});
    }
  }
}

// ------------------------------------------------------------
// Shared helpers
// ------------------------------------------------------------

/** Uploads a local file to fal's own storage and returns a fetchable URL. */
async function uploadLocalFile(fal, localPath, mimeType) {
  const buffer = await fs.readFile(localPath);
  const file = new File([buffer], path.basename(localPath), { type: mimeType });
  return fal.storage.upload(file);
}

/** Downloads a URL's bytes straight to a local file path. */
async function downloadToFile(url, destPath) {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Failed to download fal.ai result: HTTP ${response.status}`);
  }
  const buffer = Buffer.from(await response.arrayBuffer());
  await fs.writeFile(destPath, buffer);
}

module.exports = FalProvider;
