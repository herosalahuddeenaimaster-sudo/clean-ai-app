const fs = require('fs/promises');
const sharp = require('sharp');
const AIProvider = require('./AIProvider');
const logger = require('../logger');

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * MOCK PROVIDER
 * ---------------------------------------------------------------------
 * Does NOT call any external AI service. It simulates a believable
 * "object removal" on images using a local clone-stamp + feathered blur
 * (same technique the click-through prototype used in-browser), and for
 * video it simply passes the original clip through after a delay.
 *
 * This exists so the entire upload -> job -> poll -> result -> save flow
 * can be built and tested end-to-end before paying for a real AI API.
 * Swap AI_PROVIDER=real (see RealProviderTemplate.js) when ready.
 */
class MockProvider extends AIProvider {
  async process({ mediaPath, maskPath, mediaType, outputPath, onProgress }) {
    onProgress?.(5);

    if (mediaType === 'video') {
      return this._mockVideo({ mediaPath, outputPath, onProgress });
    }
    return this._mockImage({ mediaPath, maskPath, outputPath, onProgress });
  }

  async _mockVideo({ mediaPath, outputPath, onProgress }) {
    // Real video inpainting needs frame-by-frame processing (or a video-
    // native AI provider). The mock just echoes the source clip back so
    // the rest of the app — status polling, result screen, save-to-
    // gallery — can be fully exercised without that dependency.
    await sleep(400);
    onProgress?.(40);
    await fs.copyFile(mediaPath, outputPath);
    await sleep(400);
    onProgress?.(90);
    return { resultPath: outputPath, resultMimeType: 'video/mp4' };
  }

  async _mockImage({ mediaPath, maskPath, outputPath, onProgress }) {
    const image = sharp(mediaPath);
    const meta = await image.metadata();
    const width = meta.width || 0;
    const height = meta.height || 0;
    onProgress?.(15);

    const bbox = await this._computeMaskBBox(maskPath, width, height);
    onProgress?.(30);

    if (!bbox) {
      // No usable mask region — return the original untouched rather
      // than guessing.
      const buf = await image.jpeg({ quality: 92 }).toBuffer();
      await fs.writeFile(outputPath, buf);
      onProgress?.(90);
      return { resultPath: outputPath, resultMimeType: 'image/jpeg' };
    }

    try {
      const cleaned = await this._cloneStampPatch({ mediaPath, maskPath, width, height, bbox });
      onProgress?.(75);
      await fs.writeFile(outputPath, cleaned);
      onProgress?.(90);
      return { resultPath: outputPath, resultMimeType: 'image/jpeg' };
    } catch (err) {
      // Never fail the whole job over a cosmetic patching bug — fall
      // back to returning the source image so the user still gets a
      // result and the error is visible in logs, not in the UI.
      logger.error('MockProvider image patch failed, returning original', err);
      const buf = await sharp(mediaPath).jpeg({ quality: 92 }).toBuffer();
      await fs.writeFile(outputPath, buf);
      onProgress?.(90);
      return { resultPath: outputPath, resultMimeType: 'image/jpeg' };
    }
  }

  /**
   * Reads the mask (white/opaque = "remove this"), resizes it to the
   * source image's resolution if needed, and returns the bounding box
   * of marked pixels in source-image coordinates, padded a little.
   */
  async _computeMaskBBox(maskPath, width, height) {
    if (!width || !height) return null;

    const { data, info } = await sharp(maskPath)
      .resize(width, height, { fit: 'fill' })
      .grayscale()
      .raw()
      .toBuffer({ resolveWithObject: true });

    const THRESHOLD = 40;
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (let y = 0; y < info.height; y++) {
      const rowOffset = y * info.width;
      for (let x = 0; x < info.width; x++) {
        if (data[rowOffset + x] > THRESHOLD) {
          if (x < minX) minX = x;
          if (x > maxX) maxX = x;
          if (y < minY) minY = y;
          if (y > maxY) maxY = y;
        }
      }
    }

    if (minX === Infinity) return null; // mask was blank

    const pad = Math.max(8, Math.round(Math.max(maxX - minX, maxY - minY) * 0.1));
    const x = Math.max(0, minX - pad);
    const y = Math.max(0, minY - pad);
    const w = Math.min(width - x, maxX - minX + pad * 2);
    const h = Math.min(height - y, maxY - minY + pad * 2);
    return { x, y, w: Math.max(4, w), h: Math.max(4, h) };
  }

  /**
   * Clone-stamp: samples a same-sized patch from an adjacent, unmasked
   * part of the image, blurs it, feathers it by the (also blurred) mask
   * shape, and composites it over the marked region. Good enough for
   * simple backgrounds; a real inpainting model will do far better —
   * this only exists to make mock mode visually convincing.
   */
  async _cloneStampPatch({ mediaPath, maskPath, width, height, bbox }) {
    let sx = bbox.x - bbox.w;
    if (sx < 0) sx = bbox.x + bbox.w;
    sx = Math.max(0, Math.min(sx, width - bbox.w));
    const sy = Math.max(0, Math.min(bbox.y, height - bbox.h));

    const original = sharp(mediaPath);

    const patchRgbBuffer = await original
      .clone()
      .extract({ left: Math.round(sx), top: Math.round(sy), width: Math.round(bbox.w), height: Math.round(bbox.h) })
      .blur(18)
      .removeAlpha()
      .raw()
      .toBuffer();

    const alphaBuffer = await sharp(maskPath)
      .resize(width, height, { fit: 'fill' })
      .extract({ left: Math.round(bbox.x), top: Math.round(bbox.y), width: Math.round(bbox.w), height: Math.round(bbox.h) })
      .grayscale()
      .blur(10)
      .raw()
      .toBuffer();

    const patchRgba = await sharp(patchRgbBuffer, {
      raw: { width: Math.round(bbox.w), height: Math.round(bbox.h), channels: 3 },
    })
      .joinChannel(alphaBuffer, {
        raw: { width: Math.round(bbox.w), height: Math.round(bbox.h), channels: 1 },
      })
      .png()
      .toBuffer();

    return original
      .clone()
      .composite([{ input: patchRgba, left: Math.round(bbox.x), top: Math.round(bbox.y), blend: 'over' }])
      .jpeg({ quality: 92 })
      .toBuffer();
  }
}

module.exports = MockProvider;
