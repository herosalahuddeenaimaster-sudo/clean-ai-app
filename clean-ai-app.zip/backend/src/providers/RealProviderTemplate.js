const AIProvider = require('./AIProvider');
const config = require('../config');
const ApiError = require('../errors/ApiError');

/**
 * TEMPLATE for a real inpainting/editing provider. Nothing in here calls
 * a real vendor yet, on purpose — the brief this was built from didn't
 * specify one, and invented endpoints/parameters would just be wrong.
 *
 * To wire up a real vendor:
 *   1. Set AI_PROVIDER=real and fill in AI_API_KEY / AI_API_BASE_URL in .env
 *   2. Replace the TODOs below with that vendor's actual upload/inpaint/
 *      poll calls (most image-inpainting APIs want the source image +
 *      mask image, and either respond synchronously or give you a job id
 *      to poll — check the vendor's docs for the exact contract).
 *   3. Map their response back to { resultPath, resultMimeType } and
 *      write the result bytes to `outputPath`.
 *
 * Nothing outside this file needs to change — routes and the queue only
 * depend on the AIProvider interface.
 */
class RealProviderTemplate extends AIProvider {
  constructor() {
    super();
    if (!config.aiApiKey || !config.aiApiBaseUrl) {
      // Fail loudly at startup rather than mysteriously at job time.
      throw ApiError.internal(
        'PROVIDER_NOT_CONFIGURED',
        'AI_PROVIDER=real but AI_API_KEY / AI_API_BASE_URL are not set.'
      );
    }
  }

  async process({ mediaPath, maskPath, mediaType, outputPath, onProgress }) {
    // TODO: implement against your chosen vendor. Example shape only —
    // do not assume this endpoint/payload is real:
    //
    //   const form = new FormData();
    //   form.append('image', fs.createReadStream(mediaPath));
    //   form.append('mask', fs.createReadStream(maskPath));
    //   const res = await fetch(`${config.aiApiBaseUrl}/v1/<vendor-endpoint>`, {
    //     method: 'POST',
    //     headers: { Authorization: `Bearer ${config.aiApiKey}` },
    //     body: form,
    //   });
    //   ... handle sync response OR poll a job id, per the vendor's docs ...
    //   onProgress?.(90);
    //   fs.writeFileSync(outputPath, resultBytes);
    //   return { resultPath: outputPath, resultMimeType: mediaType === 'video' ? 'video/mp4' : 'image/jpeg' };

    throw ApiError.internal(
      'PROVIDER_NOT_IMPLEMENTED',
      'RealProviderTemplate is a stub. Implement it against your chosen AI vendor before using AI_PROVIDER=real.'
    );
  }
}

module.exports = RealProviderTemplate;
