const config = require('../config');
const MockProvider = require('./MockProvider');
const FalProvider = require('./FalProvider');
const logger = require('../logger');

let instance = null;

/** Lazily construct and cache the configured provider (singleton per process). */
function getProvider() {
  if (instance) return instance;

  if (config.aiProvider === 'fal') {
    logger.info('AI provider: fal.ai (object-removal/mask + void-video-inpainting)');
    instance = new FalProvider();
  } else {
    logger.info('AI provider: mock (no external calls, no cost)');
    instance = new MockProvider();
  }
  return instance;
}

module.exports = { getProvider };
