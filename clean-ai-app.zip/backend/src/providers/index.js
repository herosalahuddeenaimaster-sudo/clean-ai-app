const config = require('../config');
const MockProvider = require('./MockProvider');
const RealProviderTemplate = require('./RealProviderTemplate');
const logger = require('../logger');

let instance = null;

/** Lazily construct and cache the configured provider (singleton per process). */
function getProvider() {
  if (instance) return instance;

  if (config.aiProvider === 'real') {
    logger.info('AI provider: real (RealProviderTemplate)');
    instance = new RealProviderTemplate();
  } else {
    logger.info('AI provider: mock (no external calls, no cost)');
    instance = new MockProvider();
  }
  return instance;
}

module.exports = { getProvider };
