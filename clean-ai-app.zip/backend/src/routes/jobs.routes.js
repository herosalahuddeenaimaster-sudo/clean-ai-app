const express = require('express');
const fs = require('fs');
const ApiError = require('../errors/ApiError');
const jobStore = require('../services/jobStore');
const fileStore = require('../services/fileStore');
const jobQueue = require('../services/jobQueue');

const router = express.Router();

/**
 * POST /api/jobs
 * JSON body: { mediaFileId, maskFileId, mediaType }
 * Both fileIds must come from prior POST /api/upload calls.
 *
 * Response: 201 + job status object (see jobStore.toPublicJson)
 */
router.post('/jobs', (req, res, next) => {
  try {
    const { mediaFileId, maskFileId, mediaType } = req.body || {};

    if (!mediaFileId || !maskFileId) {
      throw ApiError.badRequest('MISSING_FIELDS', 'mediaFileId and maskFileId are required.');
    }
    if (mediaType !== 'image' && mediaType !== 'video') {
      throw ApiError.badRequest('INVALID_MEDIA_TYPE', 'mediaType must be "image" or "video".');
    }

    const mediaFile = fileStore.get(mediaFileId);
    const maskFile = fileStore.get(maskFileId);
    if (!mediaFile) throw ApiError.notFound('MEDIA_NOT_FOUND', 'mediaFileId does not match an uploaded file (it may have expired).');
    if (!maskFile) throw ApiError.notFound('MASK_NOT_FOUND', 'maskFileId does not match an uploaded file (it may have expired).');
    if (mediaFile.kind !== mediaType) {
      throw ApiError.badRequest('MEDIA_TYPE_MISMATCH', `mediaFileId was uploaded as ${mediaFile.kind}, not ${mediaType}.`);
    }
    if (maskFile.kind !== 'mask') {
      throw ApiError.badRequest('NOT_A_MASK', 'maskFileId does not refer to a mask (PNG) upload.');
    }

    const job = jobStore.create({ mediaType, mediaFileId, maskFileId });
    jobQueue.enqueue(job.id);

    res.status(201).json(jobStore.toPublicJson(job));
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/jobs/:jobId
 * Response: job status object. The Android app polls this until
 * status is "completed" or "failed".
 */
router.get('/jobs/:jobId', (req, res, next) => {
  try {
    const job = jobStore.get(req.params.jobId);
    if (!job) throw ApiError.notFound('JOB_NOT_FOUND', 'No job with that id.');
    res.json(jobStore.toPublicJson(job));
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/jobs/:jobId/result
 * Streams the finished file once status === "completed".
 */
router.get('/jobs/:jobId/result', (req, res, next) => {
  try {
    const job = jobStore.get(req.params.jobId);
    if (!job) throw ApiError.notFound('JOB_NOT_FOUND', 'No job with that id.');

    if (job.status !== 'completed') {
      throw ApiError.conflict('JOB_NOT_READY', `Job status is "${job.status}", not "completed" yet.`);
    }

    const resultFile = fileStore.get(job.resultFileId);
    if (!resultFile || !fs.existsSync(resultFile.absolutePath)) {
      throw ApiError.notFound('RESULT_EXPIRED', 'The result file is no longer available (it may have passed its retention period).');
    }

    res.setHeader('Content-Type', resultFile.mimeType);
    res.setHeader('Content-Disposition', `attachment; filename="${resultFile.originalName}"`);
    fs.createReadStream(resultFile.absolutePath).pipe(res);
  } catch (err) {
    next(err);
  }
});

/**
 * DELETE /api/jobs/:jobId
 * Cancels a queued or in-progress job (best-effort — a job already
 * mid-processing in a real provider may still finish server-side, but
 * the Android app stops waiting on it and the result is discarded).
 */
router.delete('/jobs/:jobId', (req, res, next) => {
  try {
    const job = jobQueue.cancel(req.params.jobId);
    if (!job) throw ApiError.notFound('JOB_NOT_FOUND', 'No job with that id.');
    res.json(jobStore.toPublicJson(job));
  } catch (err) {
    next(err);
  }
});

module.exports = router;
