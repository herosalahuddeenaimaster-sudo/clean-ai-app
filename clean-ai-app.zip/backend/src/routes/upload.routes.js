const express = require('express');
const multer = require('multer');
const path = require('path');
const { v4: uuid } = require('uuid');
const config = require('../config');
const ApiError = require('../errors/ApiError');
const fileStore = require('../services/fileStore');
const { kindForMime, maxBytesForKind } = require('../services/fileValidation');

const router = express.Router();

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, config.uploadDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname) || '';
    cb(null, `${uuid()}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: Math.max(config.maxImageSizeMb, config.maxVideoSizeMb) * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const kind = kindForMime(file.mimetype);
    if (!kind) {
      cb(ApiError.unsupportedMedia('UNSUPPORTED_FILE_TYPE', `${file.mimetype} is not a supported image, video, or mask type.`));
      return;
    }
    cb(null, true);
  },
});

/**
 * POST /api/upload
 * multipart/form-data, field name "file".
 * Used for the source media (image/video) AND for the generated mask —
 * call it twice per job, once for each.
 *
 * Response: { fileId, kind, mimeType, sizeBytes }
 */
router.post('/upload', upload.single('file'), (req, res, next) => {
  try {
    if (!req.file) {
      throw ApiError.badRequest('NO_FILE', 'No file was included in the request (expected field "file").');
    }

    const kind = kindForMime(req.file.mimetype);
    const maxBytes = maxBytesForKind(kind);
    if (req.file.size > maxBytes) {
      throw ApiError.payloadTooLarge(
        'FILE_TOO_LARGE',
        `File is ${(req.file.size / (1024 * 1024)).toFixed(1)}MB, which exceeds the ${(maxBytes / (1024 * 1024)).toFixed(0)}MB limit for ${kind} files.`
      );
    }

    const record = fileStore.register({
      absolutePath: req.file.path,
      originalName: req.file.originalname,
      mimeType: req.file.mimetype,
      kind,
      sizeBytes: req.file.size,
    });

    res.status(201).json({
      fileId: record.id,
      kind: record.kind,
      mimeType: record.mimeType,
      sizeBytes: record.sizeBytes,
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
