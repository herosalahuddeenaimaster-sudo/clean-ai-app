const fs = require('fs/promises');
const config = require('../config');
const logger = require('../logger');
const fileStore = require('./fileStore');
const jobStore = require('./jobStore');

const SWEEP_INTERVAL_MS = 5 * 60 * 1000; // every 5 minutes
let timer = null;

async function sweepOnce() {
  const cutoff = Date.now() - config.fileRetentionMinutes * 60 * 1000;
  let removed = 0;

  for (const file of fileStore.all()) {
    if (file.createdAt < cutoff) {
      try {
        await fs.unlink(file.absolutePath);
      } catch (err) {
        if (err.code !== 'ENOENT') logger.warn('cleanup: could not delete file', file.absolutePath, err.message);
      }
      fileStore.remove(file.id);
      removed++;
    }
  }

  // Jobs referencing expired files are no longer useful to keep around either.
  for (const job of jobStore.all()) {
    if (job.createdAt < cutoff && (job.status === 'completed' || job.status === 'failed' || job.status === 'cancelled')) {
      // jobStore has no delete() by design (keeps a short audit trail in
      // memory); this is where you'd call jobStore.remove(job.id) if you
      // add one, or expire rows in a real database with a TTL/cron.
    }
  }

  if (removed > 0) logger.info(`cleanup: removed ${removed} expired file(s)`);
}

function start() {
  if (timer) return;
  timer = setInterval(() => {
    sweepOnce().catch((err) => logger.error('cleanup sweep failed', err));
  }, SWEEP_INTERVAL_MS);
  timer.unref?.(); // don't keep the process alive just for this timer
  logger.info(`cleanup service started (retention: ${config.fileRetentionMinutes}min, sweep every ${SWEEP_INTERVAL_MS / 60000}min)`);
}

function stop() {
  if (timer) clearInterval(timer);
  timer = null;
}

module.exports = { start, stop, sweepOnce };
