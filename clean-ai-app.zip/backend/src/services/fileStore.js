const { v4: uuid } = require('uuid');

/**
 * In-memory map of fileId -> file record. Fine for a single-instance
 * MVP/mock deployment. For multi-instance production, back this with
 * a real database (Postgres/Redis) so any instance can see any job —
 * nothing outside this file needs to know that happened.
 */
const files = new Map();

function register({ absolutePath, originalName, mimeType, kind, sizeBytes }) {
  const id = uuid();
  const record = {
    id,
    absolutePath,
    originalName,
    mimeType,
    kind, // 'image' | 'video' | 'mask'
    sizeBytes,
    createdAt: Date.now(),
  };
  files.set(id, record);
  return record;
}

function get(id) {
  return files.get(id) || null;
}

function remove(id) {
  files.delete(id);
}

function all() {
  return Array.from(files.values());
}

module.exports = { register, get, remove, all };
