const config = require('../config');

const ALLOWED_IMAGE_MIME = new Set(['image/jpeg', 'image/png', 'image/webp']);
const ALLOWED_VIDEO_MIME = new Set(['video/mp4', 'video/quicktime', 'video/x-matroska', 'video/webm']);
// Masks are always generated as PNG (opaque = keep, transparent/black = remove).
const ALLOWED_MASK_MIME = new Set(['image/png']);

function kindForMime(mime) {
  if (ALLOWED_IMAGE_MIME.has(mime)) return 'image';
  if (ALLOWED_VIDEO_MIME.has(mime)) return 'video';
  if (ALLOWED_MASK_MIME.has(mime)) return 'mask';
  return null;
}

function maxBytesForKind(kind) {
  if (kind === 'video') return config.maxVideoSizeMb * 1024 * 1024;
  // images and masks share the (smaller) image limit
  return config.maxImageSizeMb * 1024 * 1024;
}

module.exports = {
  ALLOWED_IMAGE_MIME,
  ALLOWED_VIDEO_MIME,
  ALLOWED_MASK_MIME,
  kindForMime,
  maxBytesForKind,
};
