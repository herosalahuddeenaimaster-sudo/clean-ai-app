const path = require('path');
const config = require('../config');
const logger = require('../logger');
const jobStore = require('./jobStore');
const fileStore = require('./fileStore');
const { getProvider } = require('../providers');

/**
 * Minimal FIFO queue processed by a single in-process worker loop. This
 * is intentionally simple: fine for one backend instance handling
 * moderate load. To scale horizontally, swap this file's internals for
 * BullMQ + Redis (or SQS, Cloud Tasks, etc) — jobStore's public API
 * (create/get/update) stays the same either way, so routes never notice
 * the difference.
 */
const pending = [];
let workerRunning = false;

function enqueue(jobId) {
  pending.push(jobId);
  if (!workerRunning) {
    workerRunning = true;
    setImmediate(runWorker);
  }
}

async function runWorker() {
  while (pending.length > 0) {
    const jobId = pending.shift();
    await runJob(jobId).catch((err) => {
      logger.error(`Unhandled error processing job ${jobId}`, err);
    });
  }
  workerRunning = false;
}

async function runJob(jobId) {
  const job = jobStore.get(jobId);
  if (!job || job.status === 'cancelled') return;

  const mediaFile = fileStore.get(job.mediaFileId);
  const maskFile = fileStore.get(job.maskFileId);
  if (!mediaFile || !maskFile) {
    jobStore.update(jobId, {
      status: 'failed',
      error: { code: 'SOURCE_FILE_MISSING', message: 'Uploaded media or mask could not be found (it may have expired).' },
    });
    return;
  }

  jobStore.update(jobId, { status: 'processing', progress: 5 });

  const ext = job.mediaType === 'video' ? '.mp4' : '.jpg';
  const outputPath = path.join(config.resultDir, `${jobId}${ext}`);

  try {
    const provider = getProvider();
    const result = await provider.process({
      mediaPath: mediaFile.absolutePath,
      maskPath: maskFile.absolutePath,
      mediaType: job.mediaType,
      outputPath,
      onProgress: (pct) => {
        // A job can be cancelled mid-flight; stop reporting progress for it.
        const current = jobStore.get(jobId);
        if (current && current.status !== 'cancelled') {
          jobStore.update(jobId, { progress: Math.min(99, Math.max(0, Math.round(pct))) });
        }
      },
    });

    const latest = jobStore.get(jobId);
    if (!latest || latest.status === 'cancelled') return;

    const resultFile = fileStore.register({
      absolutePath: result.resultPath,
      originalName: `${jobId}${ext}`,
      mimeType: result.resultMimeType,
      kind: job.mediaType,
      sizeBytes: null,
    });

    jobStore.update(jobId, {
      status: 'completed',
      progress: 100,
      resultFileId: resultFile.id,
      resultMimeType: result.resultMimeType,
    });
    logger.info(`Job ${jobId} completed`);
  } catch (err) {
    logger.error(`Job ${jobId} failed`, err);
    jobStore.update(jobId, {
      status: 'failed',
      error: { code: 'PROCESSING_FAILED', message: 'The AI provider could not process this media. Please try again.' },
    });
  }
}

function cancel(jobId) {
  const job = jobStore.get(jobId);
  if (!job) return null;
  if (job.status === 'queued' || job.status === 'processing') {
    const idx = pending.indexOf(jobId);
    if (idx >= 0) pending.splice(idx, 1);
    return jobStore.update(jobId, { status: 'cancelled' });
  }
  return job;
}

module.exports = { enqueue, cancel };
