const { v4: uuid } = require('uuid');

/**
 * JOB LIFECYCLE
 *   queued -> processing -> completed
 *                        \-> failed
 *   (queued|processing) -> cancelled   (client explicitly cancels)
 *
 * Same swap-for-a-real-database note as fileStore.js applies here.
 */
const jobs = new Map();

function create({ mediaType, mediaFileId, maskFileId }) {
  const id = uuid();
  const job = {
    id,
    status: 'queued',
    progress: 0,
    mediaType,
    mediaFileId,
    maskFileId,
    resultFileId: null,
    resultMimeType: null,
    error: null,
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
  jobs.set(id, job);
  return job;
}

function get(id) {
  return jobs.get(id) || null;
}

function update(id, patch) {
  const job = jobs.get(id);
  if (!job) return null;
  Object.assign(job, patch, { updatedAt: Date.now() });
  return job;
}

function all() {
  return Array.from(jobs.values());
}

/** Public shape returned to the Android app — internal file paths never leave this process. */
function toPublicJson(job) {
  if (!job) return null;
  return {
    jobId: job.id,
    status: job.status,
    progress: job.progress,
    mediaType: job.mediaType,
    error: job.error,
    createdAt: job.createdAt,
    updatedAt: job.updatedAt,
    resultAvailable: job.status === 'completed' && !!job.resultFileId,
  };
}

module.exports = { create, get, update, all, toPublicJson };
