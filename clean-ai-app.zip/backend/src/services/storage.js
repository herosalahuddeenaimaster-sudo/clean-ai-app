const fs = require('fs');
const config = require('../config');

/**
 * Local-disk storage for the MVP/mock setup. In production, swap the
 * body of these functions for S3/GCS calls — nothing outside this file
 * needs to change, since routes and providers only deal in absolute
 * local paths handed back by this module.
 */
function ensureDirs() {
  for (const dir of [config.uploadDir, config.resultDir]) {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }
}

module.exports = { ensureDirs };
