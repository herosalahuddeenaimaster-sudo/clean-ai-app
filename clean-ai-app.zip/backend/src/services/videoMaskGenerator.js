const ffmpeg = require('fluent-ffmpeg');
const ffmpegPath = require('@ffmpeg-installer/ffmpeg').path;
const ffprobePath = require('@ffprobe-installer/ffprobe').path;

ffmpeg.setFfmpegPath(ffmpegPath);
ffmpeg.setFfprobePath(ffprobePath);

/** Reads duration (seconds) and frame rate (fps) from a video file via ffprobe. */
function probeVideo(videoPath) {
  return new Promise((resolve, reject) => {
    ffmpeg.ffprobe(videoPath, (err, data) => {
      if (err) return reject(err);

      const duration = Number(data.format && data.format.duration) || 3;
      const videoStream = (data.streams || []).find((s) => s.codec_type === 'video');

      let fps = 24;
      if (videoStream && videoStream.avg_frame_rate) {
        const [num, den] = videoStream.avg_frame_rate.split('/').map(Number);
        if (den) fps = num / den;
      }
      if (!fps || Number.isNaN(fps) || fps <= 0) fps = 24;

      resolve({ duration, fps });
    });
  });
}

/**
 * Loops a single static mask image into a video matching [referenceVideoPath]'s
 * duration and frame rate. This treats the marked region as stationary for
 * the whole clip — a reasonable approximation for a single user-drawn mask,
 * though it won't track a moving object. Real per-frame tracking would need
 * a video segmentation model, which is out of scope for this mask tool.
 */
async function generateStaticMaskVideo({ maskImagePath, referenceVideoPath, outputPath }) {
  const { duration, fps } = await probeVideo(referenceVideoPath);

  await new Promise((resolve, reject) => {
    ffmpeg()
      .input(maskImagePath)
      .inputOptions(['-loop 1'])
      .outputOptions([
        `-t ${Math.max(0.5, duration)}`,
        `-r ${fps}`,
        '-pix_fmt yuv420p',
        // libx264 requires even width/height — round down to the nearest even number.
        '-vf scale=trunc(iw/2)*2:trunc(ih/2)*2',
      ])
      .videoCodec('libx264')
      .noAudio()
      .on('end', resolve)
      .on('error', reject)
      .save(outputPath);
  });

  return outputPath;
}

module.exports = { probeVideo, generateStaticMaskVideo };
